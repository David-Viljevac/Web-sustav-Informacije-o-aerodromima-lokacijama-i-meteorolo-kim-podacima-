package org.foi.nwtis.dviljevac.aplikacija_4.ws;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.dviljevac.aplikacija_4.podaci.Korisnik;
import jakarta.annotation.Resource;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;

/**
 * Klasa WsKorisnici koja stvara API vezu prema podacima za korisnike i upisavanje novih
 * 
 * @author David Viljevac
 * 
 * 
 *
 */
@WebService(serviceName = "korisnici")
public class WsKorisnici {

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  @Resource
  WebServiceContext wsContext;

  /**
   * API za dohvaćanje svih korisnika
   * 
   * @param korisnik
   * @param lozinka
   * @param traziImeKorisnika
   * @param traziPrezimeKorisnika
   * @return
   * @throws PogresnaAutentikacija
   */
  @WebMethod
  public List<Korisnik> dajKorisnike(@WebParam String korisnik, @WebParam String lozinka,
      @WebParam String traziImeKorisnika, @WebParam String traziPrezimeKorisnika) {
    List<Korisnik> korisnici = new ArrayList<>();
    boolean provjera = autentikacijaKorisnika(korisnik, lozinka);
    if (!provjera) {
      return korisnici;
    }

    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);
    upisiUDnevnik(request);

    Korisnik k = null;

    String query = "SELECT * from KORISNICI";

    if (traziImeKorisnika.length() > 1) {
      query = "SELECT * from KORISNICI WHERE IME LIKE ?";
    }
    if (traziPrezimeKorisnika.length() > 1) {
      query = "SELECT * from KORISNICI WHERE PREZIME LIKE ?";
    }
    if (traziImeKorisnika.length() > 1 && traziPrezimeKorisnika.length() > 1) {
      query = "SELECT * from KORISNICI WHERE IME = ? AND PREZIME = ?";
    }

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      if (traziImeKorisnika.length() > 1) {
        stat.setString(1, traziImeKorisnika);
      }
      if (traziPrezimeKorisnika.length() > 1) {
        stat.setString(1, traziPrezimeKorisnika);
      }
      if (traziImeKorisnika.length() > 1 && traziPrezimeKorisnika.length() > 1) {
        stat.setString(1, traziImeKorisnika);
        stat.setString(2, traziPrezimeKorisnika);
      }
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        k = new Korisnik();
        k.setIme(rs.getString("IME"));
        k.setPrezime(rs.getString("PREZIME"));
        k.setKorIme(rs.getString("KORIME"));
        k.setLozinka(rs.getString("LOZINKA"));
        korisnici.add(k);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    return korisnici;

  }

  /**
   * API za dohvaćanje jednog korisnika po korisnickom imenu
   * 
   * @param korisnik
   * @param lozinka
   * @param traziKorisnika
   * @return
   * @throws PogresnaAutentikacija
   */
  @WebMethod
  public Korisnik dajKorisnika(@WebParam String korisnik, @WebParam String lozinka,
      @WebParam String traziKorisnika) {
    Korisnik k = null;
    boolean provjera = autentikacijaKorisnika(korisnik, lozinka);
    if (!provjera) {
      return k;
    }


    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);
    upisiUDnevnik(request);


    String query = "SELECT * from KORISNICI WHERE KORIME LIKE ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, traziKorisnika);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        k = new Korisnik();
        k.setIme(rs.getString("IME"));
        k.setPrezime(rs.getString("PREZIME"));
        k.setKorIme(rs.getString("KORIME"));
        k.setLozinka(rs.getString("LOZINKA"));
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    return k;

  }

  /**
   * API za dodavanje korisnika u bazu
   * 
   * @param korisnik
   * @return
   */
  @WebMethod
  public boolean dodajKorisnika(@WebParam Korisnik korisnik) {

    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);
    upisiUDnevnik(request);
    String query = "INSERT INTO KORISNICI (korime, lozinka, ime, prezime) VALUES(?,?,?,?)";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, korisnik.getKorIme());
      stat.setString(2, korisnik.getLozinka());
      stat.setString(3, korisnik.getIme());
      stat.setString(4, korisnik.getPrezime());
      stat.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return false;
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    // FALI NESTO ZA WEBSOCKET
    return true;

  }

  @WebMethod
  public boolean autentikacijaKorisnika(String korisnik, String lozinka) {
    System.out.println("korisnik: " + korisnik);
    PreparedStatement pstmt = null;
    boolean autentikacija = false;
    String query = "SELECT * FROM KORISNICI WHERE KORIME = ? AND LOZINKA = ?";
    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      pstmt.setString(1, korisnik);
      pstmt.setString(2, lozinka);
      ResultSet rs = pstmt.executeQuery();
      while (rs.next()) {
        autentikacija = true;
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
    } finally {
      try {
        if (pstmt != null && pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
      }
    }
    return autentikacija;
  }

  /**
   * Metoda za upisivanje zahtjeva u tablicu "DNEVNIK" za aplikaciju 4
   * 
   * @param request HTTP zahtjev
   */
  private void upisiUDnevnik(HttpServletRequest request) {
    String metoda = request.getMethod();
    String putanja = request.getRequestURI();
    String adresa = request.getRemoteAddr();

    String query = "INSERT INTO DNEVNIK (metoda, putanja, adresa, vrsta) VALUES (?, ?, ?, ?)";

    try (Connection con = ds.getConnection();
        PreparedStatement stat = con.prepareStatement(query)) {
      stat.setString(1, metoda);
      stat.setString(2, putanja);
      stat.setString(3, adresa);
      stat.setString(4, "AP4");
      stat.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

}
