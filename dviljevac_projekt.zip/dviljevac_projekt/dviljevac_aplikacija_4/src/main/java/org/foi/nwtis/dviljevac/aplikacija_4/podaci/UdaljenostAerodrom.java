package org.foi.nwtis.dviljevac.aplikacija_4.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public record UdaljenostAerodrom(String icao, float km) {

}
