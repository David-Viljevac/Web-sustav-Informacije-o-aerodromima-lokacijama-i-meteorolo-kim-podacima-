package org.foi.nwtis.dviljevac.aplikacija_4.ws;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.dviljevac.aplikacija_4.podaci.AerodromStatus;
import org.foi.nwtis.dviljevac.aplikacija_4.podaci.AerodromStatusString;
import org.foi.nwtis.dviljevac.aplikacija_4.podaci.Lokacija;
import jakarta.annotation.Resource;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;

/**
 * Klasa WsAerodromi koja stvara API vezu prema podacima za aerodrome za koje se treba preuzeti
 * letove i upisavanje novih
 * 
 * @author David Viljevac
 * 
 * 
 *
 */
@WebService(serviceName = "aerodromi")
public class WsAerodromi {

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  @Resource
  WebServiceContext wsContext;

  /**
   * API za dohvaćanje aerodrome za letove
   * 
   * @param korisnik
   * @param lozinka
   * @return
   */
  @WebMethod
  public List<AerodromStatus> dajAerodromeZaLetove(@WebParam String korisnik,
      @WebParam String lozinka) {
    List<AerodromStatus> aerodromi = new ArrayList();
    boolean provjera = autentikacijaKorisnika(korisnik, lozinka);
    if (!provjera) {
      return aerodromi;
    }
    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);
    upisiUDnevnik(request);

    List<AerodromStatusString> aerodromiS = new ArrayList();
    String query = "SELECT * FROM AERODROMI_LETOVI";
    AerodromStatusString ads = null;
    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ads = new AerodromStatusString();
        ads.setIcao(rs.getString("ICAO"));
        ads.setStatus(rs.getBoolean("STATUS"));;
        aerodromiS.add(ads);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    for (AerodromStatusString icao : aerodromiS) {
      AerodromStatus ad = null;
      query = "SELECT * FROM AIRPORTS WHERE ICAO LIKE ?";
      stat = null;
      try (Connection con = ds.getConnection()) {
        stat = con.prepareStatement(query);
        stat.setString(1, icao.getIcao());
        ResultSet rs = stat.executeQuery();

        while (rs.next()) {
          ad = new AerodromStatus();
          ad.setIcao(rs.getString("ICAO"));
          ad.setDrzava(rs.getString("ISO_COUNTRY"));
          ad.setNaziv(rs.getString("NAME"));
          ad.setStatus(icao.isStatus());
          String koordinate = rs.getString("COORDINATES");
          String[] kord = koordinate.split(",");
          Lokacija lokacija = new Lokacija(kord[0], kord[1]);
          ad.setLokacija(lokacija);
          aerodromi.add(ad);
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      } finally {
        try {
          if (stat != null && !stat.isClosed()) {
            stat.close();
          }
        } catch (SQLException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      }
    }
    return aerodromi;
  }

  /**
   * API za dodavanje aerodroma za letove u bazu podataka
   * 
   * @param korisnik
   * @param lozinka
   * @param icao
   * @return
   */
  @WebMethod
  public boolean dodajAerodromZaLetove(@WebParam String korisnik, @WebParam String lozinka,
      @WebParam String icao) {
    boolean provjera = autentikacijaKorisnika(korisnik, lozinka);
    if (!provjera) {
      return false;
    }
    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);
    upisiUDnevnik(request);

    String query = "INSERT INTO AERODROMI_LETOVI (icao, status) VALUES(?,?)";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, icao);
      stat.setBoolean(2, true);
      stat.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block

      e.printStackTrace();
      return false;
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
        return false;
      }
    }
    return true;

  }

  /**
   * API za pauziranje preuzimanja letova za neki aerodrom
   * 
   * @param korisnik
   * @param lozinka
   * @param icao
   * @return
   */
  @WebMethod
  public boolean pauzirajAerodromZaletove(@WebParam String korisnik, @WebParam String lozinka,
      @WebParam String icao) {
    boolean provjera = autentikacijaKorisnika(korisnik, lozinka);
    if (!provjera) {
      return false;
    }
    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);
    upisiUDnevnik(request);
    String query = "UPDATE AERODROMI_LETOVI SET status = ? WHERE icao LIKE ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setBoolean(1, false);
      stat.setString(2, icao);
      stat.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return false;
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
        return false;
      }
    }
    return true;
  }

  /**
   * API za aktiviranje preuzimanja letova za neki aerodrom
   * 
   * @param korisnik
   * @param lozinka
   * @param icao
   * @return
   */
  @WebMethod
  public boolean aktivirajAerodromZaletove(@WebParam String korisnik, @WebParam String lozinka,
      @WebParam String icao) {
    boolean provjera = autentikacijaKorisnika(korisnik, lozinka);
    if (!provjera) {
      return false;
    }
    MessageContext context = wsContext.getMessageContext();
    HttpServletRequest request = (HttpServletRequest) context.get(MessageContext.SERVLET_REQUEST);

    upisiUDnevnik(request);
    String query = "UPDATE AERODROMI_LETOVI SET status = ? WHERE icao LIKE ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setBoolean(1, true);
      stat.setString(2, icao);
      stat.executeUpdate();
    } catch (SQLException e) {

      e.printStackTrace();
      return false;
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
        return false;
      }
    }
    return true;
  }

  /**
   * Metoda za upisivanje zahtjeva u tablicu "DNEVNIK" za aplikaciju 4
   * 
   * @param request HTTP zahtjev
   */
  private void upisiUDnevnik(HttpServletRequest request) {
    String metoda = request.getMethod();
    String putanja = request.getRequestURI();
    String adresa = request.getRemoteAddr();

    String query = "INSERT INTO DNEVNIK (metoda, putanja, adresa, vrsta) VALUES (?, ?, ?, ?)";

    try (Connection con = ds.getConnection();
        PreparedStatement stat = con.prepareStatement(query)) {
      stat.setString(1, metoda);
      stat.setString(2, putanja);
      stat.setString(3, adresa);
      stat.setString(4, "AP4");
      stat.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }


  /**
   * Metoda autentikacije korisnika
   * 
   * @param korisnik
   * @param lozinka
   * @return
   */
  public boolean autentikacijaKorisnika(String korisnik, String lozinka) {
    System.out.println("korisnik: " + korisnik);
    PreparedStatement pstmt = null;
    boolean autentikacija = false;
    String query = "SELECT * FROM KORISNICI WHERE KORIME = ? AND LOZINKA = ?";
    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      pstmt.setString(1, korisnik);
      pstmt.setString(2, lozinka);
      ResultSet rs = pstmt.executeQuery();
      while (rs.next()) {
        autentikacija = true;
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
    } finally {
      try {
        if (pstmt != null && pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
      }
    }
    return autentikacija;
  }

}
