package org.foi.nwtis.dviljevac.aplikacija_4.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public record UdaljenostAerodromDrzava(String icao, String drzava, float km) {

}
