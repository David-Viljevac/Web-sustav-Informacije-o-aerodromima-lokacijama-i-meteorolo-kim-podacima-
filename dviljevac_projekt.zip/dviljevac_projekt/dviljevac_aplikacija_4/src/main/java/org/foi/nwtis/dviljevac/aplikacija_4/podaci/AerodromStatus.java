package org.foi.nwtis.dviljevac.aplikacija_4.podaci;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author David Viljevac
 */
@AllArgsConstructor()
public class AerodromStatus {

  @Getter
  @Setter
  private String icao;
  @Getter
  @Setter
  private String naziv;
  @Getter
  @Setter
  private String drzava;
  @Getter
  @Setter
  private Lokacija lokacija;
  @Getter
  @Setter
  private boolean status;

  public AerodromStatus() {}
}
