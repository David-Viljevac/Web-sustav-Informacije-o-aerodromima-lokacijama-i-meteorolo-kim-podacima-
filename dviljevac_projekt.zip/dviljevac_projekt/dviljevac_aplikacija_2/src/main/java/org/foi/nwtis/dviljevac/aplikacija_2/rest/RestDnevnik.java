package org.foi.nwtis.dviljevac.aplikacija_2.rest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.Dnevnik;
import com.google.gson.Gson;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestDnevnik
 * 
 * @author David Viljevac
 *
 */
@Path("dnevnik")
@RequestScoped
public class RestDnevnik {

  @Context
  ServletContext ctx;

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  /**
   * Metoda dohvaćanja zapisa dnevnika prema vrsti(JAX-RS, JAX-WS, UI) uz straničenje
   * 
   * @param vrsta
   * @param odBroja
   * @param broj
   * @return
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajZapiseDnevnika(@QueryParam("vrsta") String vrsta,
      @QueryParam("odBroja") @DefaultValue("0") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {

    List<Dnevnik> zapisiDnevnika = new ArrayList<>();
    Dnevnik d = null;
    String vrstaV = "";
    String query = "";

    if (vrsta == null) {
      query = "SELECT * from DNEVNIK OFFSET ? LIMIT ?";
    } else {
      if (vrsta.contains("JAX-RS")) {
        vrstaV = "AP2";
      } else if (vrsta.contains("JAX-WS")) {
        vrstaV = "AP4";
      } else if (vrsta.contains("UI")) {
        vrstaV = "AP5";
      }
      query = "SELECT * from DNEVNIK WHERE vrsta = ? OFFSET ? LIMIT ?";
    }

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      if (vrsta == null) {
        stat.setInt(1, odBroja);
        stat.setInt(2, broj);
      } else {
        stat.setString(1, vrstaV);
        stat.setInt(2, odBroja);
        stat.setInt(3, broj);
      }

      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        d = new Dnevnik(rs.getString("METODA"), rs.getString("PUTANJA"), rs.getString("ADRESA"),
            rs.getString("VRSTA"));
        zapisiDnevnika.add(d);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    Gson gson = new Gson();
    String podaci = gson.toJson(zapisiDnevnika);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * Metoda zapisivanja zapisa u dnevnik koji se koristi isključivo za UI odnosno aplikaciju 5.
   * 
   * @param request
   */
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public void upisiUDnevnik(@Context HttpServletRequest request) {
    String metoda = request.getMethod();
    String putanja = request.getRequestURI();
    String adresa = request.getRemoteAddr();

    String query = "INSERT INTO DNEVNIK (metoda, putanja, adresa, vrsta) VALUES (?, ?, ?, ?)";

    try (Connection con = ds.getConnection();
        PreparedStatement stat = con.prepareStatement(query)) {
      stat.setString(1, metoda);
      stat.setString(2, putanja);
      stat.setString(3, adresa);
      stat.setString(4, "AP5");
      stat.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}
