package org.foi.nwtis.dviljevac.aplikacija_2.rest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.Aerodrom;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.Lokacija;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.StatusOdgovor;
import org.foi.nwtis.dviljevac.aplikacija_2.slusaci.slusacAplikacije;
import com.google.gson.Gson;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestNadzor
 * 
 * @author David Viljevac
 *
 */
@Path("nadzor")
@RequestScoped
public class RestNadzor {

  @Context
  ServletContext ctx;

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  ServletContext kontekst = slusacAplikacije.getKontekst();
  Properties konfiguracija = (Properties) kontekst.getAttribute("konfig");
  String adresa = konfiguracija.getProperty("adresa");
  int mreznaVrata = Integer.parseInt(konfiguracija.getProperty("mreznaVrata"));


  /**
   * Metoda koja dohvaća odgovor sa poslužitelja prema poslanoj komandi KRAJ INIT i PAUZA te ga
   * interpretira.
   * 
   * @param komanda
   * @param request
   * @return
   */
  @GET
  @Path("{komanda}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajOdgovorKomande(@PathParam("komanda") String komanda,
      @Context HttpServletRequest request) {

    upisiUDnevnik(request);

    String odgovorPosluzitelja = posaljiZahtjev(komanda);
    String opis = "";
    StatusOdgovor so = null;
    if (komanda.contains("KRAJ")) {
      if (odgovorPosluzitelja.contains("OK")) {
        opis = "Poslužitelj je zaustavljen";
        so = new StatusOdgovor(200, opis);
      } else {
        so = new StatusOdgovor(400, odgovorPosluzitelja);
      }

    } else if (komanda.contains("INIT")) {
      if (odgovorPosluzitelja.contains("OK")) {
        opis = "Poslužitelj je u pokrenut";
        so = new StatusOdgovor(200, opis);
      } else {
        so = new StatusOdgovor(400, odgovorPosluzitelja);
      }

    } else if (komanda.contains("PAUZA")) {
      if (odgovorPosluzitelja.contains("OK")) {
        opis = "Poslužitelj je stavljen u pauzu";
        so = new StatusOdgovor(200, opis);
      } else {
        so = new StatusOdgovor(400, odgovorPosluzitelja);
      }
    } else {

      so = new StatusOdgovor(400, odgovorPosluzitelja);
    }
    Gson gson = new Gson();
    String podaci = gson.toJson(so);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * Metoda koja dohvaća odgovor poslužitelja za komandu status
   * 
   * @param request
   * @return
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajStatusOdgovor(@Context HttpServletRequest request) {

    upisiUDnevnik(request);

    String komanda = "STATUS";
    String odgovorPosluzitelja = posaljiZahtjev(komanda);
    String opis = "";
    StatusOdgovor so = null;
    if (odgovorPosluzitelja.contains("OK 1")) {
      opis = "Poslužitelj je aktivan";
      so = new StatusOdgovor(200, opis);

    } else if (odgovorPosluzitelja.contains("OK 0")) {
      opis = "Poslužitelj je u pauzi";
      so = new StatusOdgovor(200, opis);
    } else {
      opis = "Poslužitelj nije inicijaliziran";
      so = new StatusOdgovor(400, opis);
    }

    Gson gson = new Gson();
    String podaci = gson.toJson(so);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * Metoda koja dohvaća odgovor poslužitelja za komandu INFO DA i INFO NE
   * 
   * @param vrsta
   * @param request
   * @return
   */
  @GET
  @Path("INFO/{vrsta}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajInfoOdgovor(@PathParam("vrsta") String vrsta,
      @Context HttpServletRequest request) {

    upisiUDnevnik(request);
    String komanda = "INFO " + vrsta;
    String odgovorPosluzitelja = posaljiZahtjev(komanda);
    String opis = "";
    StatusOdgovor so = null;
    if (vrsta.contains("DA")) {
      if (odgovorPosluzitelja.contains("OK")) {
        opis = "Poslužitelj Ispisuje podatke";
        so = new StatusOdgovor(200, opis);
      } else {
        so = new StatusOdgovor(400, odgovorPosluzitelja);
      }

    } else if (vrsta.contains("NE")) {
      if (odgovorPosluzitelja.contains("OK")) {
        opis = "Poslužitelj neće više ispisivati podatke";
        so = new StatusOdgovor(200, opis);
      } else {
        so = new StatusOdgovor(400, odgovorPosluzitelja);
      }
    } else {
      so = new StatusOdgovor(400, odgovorPosluzitelja);
    }

    Gson gson = new Gson();
    String podaci = gson.toJson(so);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * Metoda za upisivanje zahtjeva u tablicu "DNEVNIK"
   * 
   * @param request HTTP zahtjev
   */
  private void upisiUDnevnik(HttpServletRequest request) {
    String metoda = request.getMethod();
    String putanja = request.getRequestURI();
    String adresa = request.getRemoteAddr();

    String query = "INSERT INTO DNEVNIK (metoda, putanja, adresa, vrsta) VALUES (?, ?, ?, ?)";

    try (Connection con = ds.getConnection();
        PreparedStatement stat = con.prepareStatement(query)) {
      stat.setString(1, metoda);
      stat.setString(2, putanja);
      stat.setString(3, adresa);
      stat.setString(4, "AP2");
      stat.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  /**
   * Šalje komandu i spaja se na mreznu uticnicu
   * 
   * @param komanda
   */
  private String posaljiZahtjev(String komanda) {
    var poruka = new StringBuilder();
    try {
      var mreznaUticnica = new Socket(adresa, mreznaVrata);
      var citac = new BufferedReader(
          new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
      var pisac = new BufferedWriter(
          new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));


      pisac.write(komanda);
      pisac.flush();
      mreznaUticnica.shutdownOutput();
      while (true) {
        var red = citac.readLine();
        if (red == null) {
          break;
        }
        poruka.append(red);
      }
      mreznaUticnica.shutdownInput();
      mreznaUticnica.close();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    String odgovor = poruka.toString();
    return odgovor;
  }

  private Aerodrom getAerodromIzBaze(String icao) {
    Aerodrom ad = new Aerodrom();

    String query = "SELECT * from AIRPORTS WHERE ICAO = ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, icao);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ad.setIcao(rs.getString("ICAO"));
        ad.setDrzava(rs.getString("ISO_COUNTRY"));
        ad.setNaziv(rs.getString("NAME"));
        String koordinate = rs.getString("COORDINATES");
        String[] kord = koordinate.split(",");
        Lokacija lokacija = new Lokacija(kord[0].trim(), kord[1].trim());
        ad.setLokacija(lokacija);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    return ad;
  }



  private List<Aerodrom> dohvatiSveAerodromeZaUdaljenostiUDrzavi(String drzava, String icaoDo) {
    List<Aerodrom> aerodromi = new ArrayList<>();

    Aerodrom ad = null;

    String query = "SELECT * from AIRPORTS WHERE ISO_COUNTRY = ? AND ICAO != ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, drzava);
      stat.setString(2, icaoDo);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ad = new Aerodrom();
        ad.setIcao(rs.getString("ICAO"));
        ad.setDrzava(rs.getString("ISO_COUNTRY"));
        ad.setNaziv(rs.getString("NAME"));
        String koordinate = rs.getString("COORDINATES");
        String[] kord = koordinate.split(",");
        Lokacija lokacija = new Lokacija(kord[0].trim(), kord[1].trim());
        ad.setLokacija(lokacija);
        aerodromi.add(ad);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    return aerodromi;
  }
}
