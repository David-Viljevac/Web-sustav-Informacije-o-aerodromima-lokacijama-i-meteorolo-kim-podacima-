package org.foi.nwtis.dviljevac.aplikacija_2.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public record UdaljenostAerodromDrzava(String icao, String drzava, float km) {

}
