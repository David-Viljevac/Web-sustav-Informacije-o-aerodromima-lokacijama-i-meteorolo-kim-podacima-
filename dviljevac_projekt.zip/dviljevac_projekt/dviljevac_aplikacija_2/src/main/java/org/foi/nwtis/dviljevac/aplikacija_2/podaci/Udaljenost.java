package org.foi.nwtis.dviljevac.aplikacija_2.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public record Udaljenost(String drzava, float km) {

}
