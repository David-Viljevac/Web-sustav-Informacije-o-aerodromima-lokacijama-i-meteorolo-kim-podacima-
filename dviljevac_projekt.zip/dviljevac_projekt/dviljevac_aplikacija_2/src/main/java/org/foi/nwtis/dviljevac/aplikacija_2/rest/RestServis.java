package org.foi.nwtis.dviljevac.aplikacija_2.rest;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import org.foi.nwtis.dviljevac.aplikacija_2.slusaci.slusacAplikacije;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.core.Context;

/**
 * Klasa RestServis
 * 
 * @author David Viljevac
 *
 */
@ApplicationPath("api")
public class RestServis extends Application {

  @Context
  ServletContext ctx;

  /**
   * Override metode getClasses u pokušaju izvršavanja uvjeta ako je statusPosluzitelja true odnosno
   * ako posluzitelj nije u pauzi
   */
  @Override
  public Set<Class<?>> getClasses() {
    Set<Class<?>> classes = new HashSet<>();

    Properties konfiguracija = new Properties();
    slusacAplikacije sA = new slusacAplikacije();
    sA.contextInitialized(new ServletContextEvent(ctx));
    ServletContext kontekst = slusacAplikacije.getKontekst();
    konfiguracija = (Properties) kontekst.getAttribute("konfig");
    String statusPosluzitelja = konfiguracija.getProperty("statusPosluzitelja");

    if (statusPosluzitelja.contains("true")) {
      classes.add(RestAerodromi.class);
      classes.add(RestNadzor.class);
      classes.add(RestDnevnik.class);
    }

    return classes;
  }

}
