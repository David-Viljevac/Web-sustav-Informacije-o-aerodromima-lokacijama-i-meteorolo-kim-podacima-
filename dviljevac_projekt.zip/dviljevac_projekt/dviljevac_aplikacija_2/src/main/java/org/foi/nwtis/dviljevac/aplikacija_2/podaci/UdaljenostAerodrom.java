package org.foi.nwtis.dviljevac.aplikacija_2.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public record UdaljenostAerodrom(String icao, float km) {

}
