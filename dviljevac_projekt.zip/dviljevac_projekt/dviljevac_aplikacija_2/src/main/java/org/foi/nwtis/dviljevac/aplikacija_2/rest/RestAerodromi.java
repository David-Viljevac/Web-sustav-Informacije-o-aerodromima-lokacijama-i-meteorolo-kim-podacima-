package org.foi.nwtis.dviljevac.aplikacija_2.rest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.Aerodrom;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.Lokacija;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.UdaljenostAerodrom;
import org.foi.nwtis.dviljevac.aplikacija_2.podaci.UdaljenostAerodromDrzava;
import org.foi.nwtis.dviljevac.aplikacija_2.slusaci.slusacAplikacije;
import com.google.gson.Gson;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa RestAerodromi
 * 
 * @author David Viljevac
 *
 */
@Path("aerodromi")
@RequestScoped
public class RestAerodromi {

  @Context
  ServletContext ctx;

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  ServletContext kontekst = slusacAplikacije.getKontekst();
  Properties konfiguracija = (Properties) kontekst.getAttribute("konfig");
  String adresa = konfiguracija.getProperty("adresa");
  int mreznaVrata = Integer.parseInt(konfiguracija.getProperty("mreznaVrata"));

  /**
   * API za dohvaćanje svih aerodroma uz mogućnost filtriranja po nazivu ili državi.
   * 
   * @param odBroja
   * @param broj
   * @param traziNaziv
   * @param traziDrzavu
   * @return
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajSveAerodrome(@QueryParam("odBroja") @DefaultValue("0") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj, @QueryParam("traziNaziv") String traziNaziv,
      @QueryParam("traziDrzavu") String traziDrzavu, @Context HttpServletRequest request) {

    upisiUDnevnik(request);
    List<Aerodrom> aerodromi = new ArrayList<>();
    Aerodrom ad = null;
    String query = "SELECT * from AIRPORTS OFFSET ? LIMIT ?";
    if (traziNaziv != null) {
      query = "SELECT * from AIRPORTS WHERE NAME LIKE ? OFFSET ? LIMIT ?";
    }
    if (traziDrzavu != null) {
      query = "SELECT * from AIRPORTS WHERE ISO_COUNTRY LIKE ? OFFSET ? LIMIT ?";
    }
    if (traziDrzavu != null && traziNaziv != null) {
      query = "SELECT * from AIRPORTS WHERE NAME LIKE ? AND ISO_COUNTRY LIKE ? OFFSET ? LIMIT ?";
    }



    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      if (traziNaziv == null && traziDrzavu == null) {
        stat.setInt(1, odBroja);
        stat.setInt(2, broj);
      }

      if (traziNaziv != null) {
        stat.setString(1, traziNaziv);
        stat.setInt(2, odBroja);
        stat.setInt(3, broj);
      }
      if (traziDrzavu != null) {
        stat.setString(1, traziDrzavu);
        stat.setInt(2, odBroja);
        stat.setInt(3, broj);
      }
      if (traziDrzavu != null && traziNaziv != null) {
        stat.setString(1, traziNaziv);
        stat.setString(2, traziDrzavu);
        stat.setInt(3, odBroja);
        stat.setInt(4, broj);
      }

      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ad = new Aerodrom();
        ad.setIcao(rs.getString("ICAO"));
        ad.setDrzava(rs.getString("ISO_COUNTRY"));
        ad.setNaziv(rs.getString("NAME"));
        String koordinate = rs.getString("COORDINATES");
        String[] kord = koordinate.split(",");
        Lokacija lokacija = new Lokacija(kord[0], kord[1]);
        ad.setLokacija(lokacija);
        aerodromi.add(ad);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    Gson gson = new Gson();
    String podaci = gson.toJson(aerodromi);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * API za dohvaćanje jednog aerodroma prema parametru.
   * 
   * @param icao
   * @return
   */
  @GET
  @Path("{icao}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajAerodrom(@PathParam("icao") String icao) {

    Aerodrom ad = null;

    String query = "SELECT * from AIRPORTS WHERE ICAO = ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, icao);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ad = new Aerodrom();
        ad.setIcao(rs.getString("ICAO"));
        ad.setDrzava(rs.getString("ISO_COUNTRY"));
        ad.setNaziv(rs.getString("NAME"));
        String koordinate = rs.getString("COORDINATES");
        String[] kord = koordinate.split(",");
        Lokacija lokacija = new Lokacija(kord[0], kord[1]);
        ad.setLokacija(lokacija);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    if (ad == null) {
      return Response.noContent().build();
    }

    Gson gson = new Gson();
    String podaci = gson.toJson(ad);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * API za dohvaćanje udaljenosti dvaju aerodroma po državama
   * 
   * @param icaoOd
   * @param icaoDo
   * @return
   */
  @GET
  @Path("{icaoOd}/{icaoDo}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajUdaljenostiAerodoma(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo, @Context HttpServletRequest request) {

    upisiUDnevnik(request);
    var udaljenosti = new ArrayList<UdaljenostAerodromDrzava>();
    String query =
        "SELECT ICAO_FROM, ICAO_TO, COUNTRY, DIST_CTRY from AIRPORTS_DISTANCE_MATRIX WHERE ICAO_FROM = ? AND ICAO_TO = ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, icaoOd);
      stat.setString(2, icaoDo);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        String drzava = rs.getString("COUNTRY");
        float udaljenost = rs.getFloat("DIST_CTRY");
        String icao = rs.getString("ICAO_TO");
        UdaljenostAerodromDrzava u = new UdaljenostAerodromDrzava(icao, drzava, udaljenost);
        udaljenosti.add(u);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    Gson gson = new Gson();
    String podaci = gson.toJson(udaljenosti);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }


  /**
   * API za dohvaćanje udaljenosti određenog aerodroma do svih drugih aerodroma.
   * 
   * @param icaoOd
   * @param odBroja
   * @param broj
   * @return
   */
  @GET
  @Path("{icaoOd}/udaljenosti")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajUdaljenostiIzmeđuSvihAerodoma(@PathParam("icaoOd") String icaoOd,
      @QueryParam("odBroja") @DefaultValue("0") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj, @Context HttpServletRequest request) {

    upisiUDnevnik(request);
    var udaljenosti = new ArrayList<UdaljenostAerodrom>();
    String query =
        "SELECT DISTINCT ICAO_FROM, COUNTRY, ICAO_TO, DIST_CTRY, DIST_TOT from AIRPORTS_DISTANCE_MATRIX WHERE ICAO_FROM = ? OFFSET ? LIMIT ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, icaoOd);
      stat.setInt(2, odBroja);
      stat.setInt(3, broj);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        String icao = rs.getString("ICAO_TO");
        float udaljenost = rs.getFloat("DIST_TOT");
        UdaljenostAerodrom u = new UdaljenostAerodrom(icao, udaljenost);
        udaljenosti.add(u);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    Gson gson = new Gson();
    String podaci = gson.toJson(udaljenosti);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }


  /**
   * API za izračun udaljenosti između dva aerodroma.
   * 
   * @param icaoOd
   * @param icaoDo
   * @return
   */
  @GET
  @Path("{icaoOd}/izracunaj/{icaoDo}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajIzracunatuUdaljenost(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo, @Context HttpServletRequest request) {

    upisiUDnevnik(request);

    Aerodrom ad1 = new Aerodrom();
    Aerodrom ad2 = new Aerodrom();

    ad1 = getAerodromIzBaze(icaoOd);
    ad2 = getAerodromIzBaze(icaoDo);

    String zahtjev =
        "UDALJENOST " + ad1.getLokacija().getLatitude() + " " + ad1.getLokacija().getLongitude()
            + " " + ad2.getLokacija().getLatitude() + " " + ad2.getLokacija().getLongitude();
    String odgovorPosluzitelja = posaljiZahtjev(zahtjev);
    double odgovorPosluziteljaD = Double.parseDouble(odgovorPosluzitelja);

    List<Aerodrom> listA = new ArrayList<>();
    listA.add(ad2);
    listA.add(ad1);

    Map<String, Object> responseData = new HashMap<>();
    responseData.put("aerodromi", listA);
    responseData.put("odgovorPosluzitelja", odgovorPosluziteljaD);

    Gson gson = new Gson();
    String podaci = gson.toJson(responseData);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }

  /**
   * API za dohvaćanje udaljenosti aerodroma unutar države zadanog aerodroma.
   * 
   * @param icaoOd
   * @param icaoDo
   * @return
   */
  @GET
  @Path("{icaoOd}/udaljenost1/{icaoDo}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajUdaljenost1IzmeduDvaAerodroma(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo, @Context HttpServletRequest request) {

    upisiUDnevnik(request);
    Aerodrom ad1 = new Aerodrom();
    Aerodrom ad2 = new Aerodrom();
    List<Aerodrom> listA = new ArrayList<>();
    List<Aerodrom> listB = new ArrayList<>();

    ad1 = getAerodromIzBaze(icaoOd);
    ad2 = getAerodromIzBaze(icaoDo);

    String zahtjev =
        "UDALJENOST " + ad1.getLokacija().getLatitude() + " " + ad1.getLokacija().getLongitude()
            + " " + ad2.getLokacija().getLatitude() + " " + ad2.getLokacija().getLongitude();
    String odgovorPosluzitelja = posaljiZahtjev(zahtjev);
    double udaljenostPrva = Double.parseDouble(odgovorPosluzitelja);


    List<Aerodrom> aerodromiPremaDrzavi =
        dohvatiSveAerodromeZaUdaljenostiUDrzavi(ad2.getDrzava(), ad2.getIcao());


    List<Map<String, Object>> aerodromiDrzavaSUdaljenosti = new ArrayList<>();
    for (Aerodrom aerodrom : aerodromiPremaDrzavi) {
      String zahtjevPoAerodromu = "UDALJENOST " + ad1.getLokacija().getLatitude() + " "
          + ad1.getLokacija().getLongitude() + " " + aerodrom.getLokacija().getLatitude() + " "
          + aerodrom.getLokacija().getLongitude();
      String odgovorPosluziteljaPoAerodromu = posaljiZahtjev(zahtjevPoAerodromu);
      double udaljenostDruga = Double.parseDouble(odgovorPosluziteljaPoAerodromu);

      if (udaljenostPrva > udaljenostDruga) {
        listB.add(aerodrom);
        Map<String, Object> aerodromMap = new HashMap<>();
        aerodromMap.put("aerodrom", aerodrom);
        aerodromMap.put("udaljenostdoIcaoDo", udaljenostDruga);
        aerodromiDrzavaSUdaljenosti.add(aerodromMap);
      }
    }

    listA.add(ad1);

    Map<String, Object> responseData = new HashMap<>();
    responseData.put("aerodromIcaoOd", listA);
    responseData.put("aerodromiIcaoDoSUdaljenostima", aerodromiDrzavaSUdaljenosti);



    Gson gson = new Gson();
    String podaci = gson.toJson(responseData);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }


  /**
   * API za dohvaćanje udaljenosti aerodroma unutar zadane države čija je udaljenost manja od
   * zadane.
   * 
   * @param icaoOd
   * @param drzava
   * @param km
   * @return
   */
  @GET
  @Path("{icaoOd}/udaljenost2")
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajUdaljenost2(@PathParam("icaoOd") String icaoOd,
      @QueryParam("drzava") String drzava, @QueryParam("km") String km,
      @Context HttpServletRequest request) {

    upisiUDnevnik(request);

    if (drzava == null || km == null) {
      return Response.status(400).entity(
          "Nedostaju parametri drzava ili km. Korisnik ne bi smio nastaviti sa slanjem zahtjeva bez modifikacije istog.")
          .build();
    }

    Aerodrom ad1 = new Aerodrom();
    Aerodrom ad2 = new Aerodrom();
    List<Aerodrom> listA = new ArrayList<>();
    List<Aerodrom> listB = new ArrayList<>();
    double udaljenostKM = Double.parseDouble(km);

    ad1 = getAerodromIzBaze(icaoOd);

    List<Aerodrom> aerodromiPremaDrzavi = dohvatiSveAerodromeZaUdaljenostiUDrzavi(drzava, "");


    List<Map<String, Object>> aerodromiDrzavaSUdaljenosti = new ArrayList<>();
    for (Aerodrom aerodrom : aerodromiPremaDrzavi) {
      String zahtjevPoAerodromu = "UDALJENOST " + ad1.getLokacija().getLatitude() + " "
          + ad1.getLokacija().getLongitude() + " " + aerodrom.getLokacija().getLatitude() + " "
          + aerodrom.getLokacija().getLongitude();
      String odgovorPosluziteljaPoAerodromu = posaljiZahtjev(zahtjevPoAerodromu);
      double udaljenostDruga = Double.parseDouble(odgovorPosluziteljaPoAerodromu);

      if (udaljenostDruga < udaljenostKM) {
        listB.add(aerodrom);
        Map<String, Object> aerodromMap = new HashMap<>();
        aerodromMap.put("aerodrom", aerodrom);
        aerodromMap.put("udaljenostdoIcaoDo", udaljenostDruga);
        aerodromiDrzavaSUdaljenosti.add(aerodromMap);
      }
    }

    listA.add(ad1);

    Map<String, Object> responseData = new HashMap<>();
    responseData.put("aerodromIcaoOd", listA);
    responseData.put("aerodromiIcaoDoSUdaljenostima", aerodromiDrzavaSUdaljenosti);



    Gson gson = new Gson();
    String podaci = gson.toJson(responseData);
    Response odgovor = Response.ok().entity(podaci).build();
    return odgovor;
  }


  /**
   * Metoda za upisivanje zahtjeva u tablicu "DNEVNIK" za aplikaciju 2
   * 
   * @param request HTTP zahtjev
   */
  private void upisiUDnevnik(HttpServletRequest request) {
    String metoda = request.getMethod();
    String putanja = request.getRequestURI();
    String adresa = request.getRemoteAddr();

    String query = "INSERT INTO DNEVNIK (metoda, putanja, adresa, vrsta) VALUES (?, ?, ?, ?)";

    try (Connection con = ds.getConnection();
        PreparedStatement stat = con.prepareStatement(query)) {
      stat.setString(1, metoda);
      stat.setString(2, putanja);
      stat.setString(3, adresa);
      stat.setString(4, "AP2");
      stat.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  /**
   * Šalje komandu i spaja se na mreznu uticnicu
   * 
   * @param komanda
   */
  private String posaljiZahtjev(String komanda) {
    var poruka = new StringBuilder();
    try {
      var mreznaUticnica = new Socket(adresa, mreznaVrata);
      var citac = new BufferedReader(
          new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
      var pisac = new BufferedWriter(
          new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));


      pisac.write(komanda);
      pisac.flush();
      mreznaUticnica.shutdownOutput();
      while (true) {
        var red = citac.readLine();
        if (red == null) {
          break;
        }
        poruka.append(red);
      }
      mreznaUticnica.shutdownInput();
      mreznaUticnica.close();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    String[] odgovor = poruka.toString().split(" ");
    return odgovor[1];
  }

  private Aerodrom getAerodromIzBaze(String icao) {
    Aerodrom ad = new Aerodrom();

    String query = "SELECT * from AIRPORTS WHERE ICAO = ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, icao);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ad.setIcao(rs.getString("ICAO"));
        ad.setDrzava(rs.getString("ISO_COUNTRY"));
        ad.setNaziv(rs.getString("NAME"));
        String koordinate = rs.getString("COORDINATES");
        String[] kord = koordinate.split(",");
        Lokacija lokacija = new Lokacija(kord[0].trim(), kord[1].trim());
        ad.setLokacija(lokacija);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    return ad;
  }

  private List<Aerodrom> dohvatiSveAerodromeZaUdaljenostiUDrzavi(String drzava, String icaoDo) {
    List<Aerodrom> aerodromi = new ArrayList<>();

    Aerodrom ad = null;

    String query = "SELECT * from AIRPORTS WHERE ISO_COUNTRY = ? AND ICAO != ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, drzava);
      stat.setString(2, icaoDo);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        ad = new Aerodrom();
        ad.setIcao(rs.getString("ICAO"));
        ad.setDrzava(rs.getString("ISO_COUNTRY"));
        ad.setNaziv(rs.getString("NAME"));
        String koordinate = rs.getString("COORDINATES");
        String[] kord = koordinate.split(",");
        Lokacija lokacija = new Lokacija(kord[0].trim(), kord[1].trim());
        ad.setLokacija(lokacija);
        aerodromi.add(ad);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    return aerodromi;
  }
}
