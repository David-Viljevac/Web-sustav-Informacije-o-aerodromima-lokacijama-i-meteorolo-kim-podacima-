#!/bin/bash

echo "Zaustavi"
docker stop dviljevac_payara_micro
echo "Obrisi"
docker rm dviljevac_payara_micro
echo "Pripremi"
./scripts/pripremiSliku.sh
echo "Pokreni"
./scripts/pokreniSliku.sh