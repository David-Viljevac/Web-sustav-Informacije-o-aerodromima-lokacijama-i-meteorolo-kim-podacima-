#!/bin/bash

docker build -t dviljevac_payara_micro:6.2023.4 . &

wait
