package org.foi.nwtis.dviljevac.aplikacija_3.web;

import java.io.IOException;
import org.foi.nwtis.dviljevac.aplikacija_3.zrna.JmsPosiljatelj;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Klasa koja šalje jms poruku u sustav
 * 
 * @author David Viljevac
 *
 */
@WebServlet(name = "SaljeJmsPoruku", urlPatterns = {"/SaljeJmsPoruku"})
public class SaljeJmsPoruku extends HttpServlet {

  private static final long serialVersionUID = -8134817489121161045L;

  @EJB
  JmsPosiljatelj jmsPosiljatelj;

  /**
   * Override metode doGet koja sada salje poruku odnosno informaciju o toj poruci u sustav
   */
  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    var poruka = req.getParameter("poruka");
    if (poruka != null && !poruka.isEmpty()) {
      if (jmsPosiljatelj.saljiPoruku(poruka)) {
        System.out.println("Poruka je poslana");
        return;
      }
      System.out.println("Greška kod slanja JMS poruke");
      return;
    }
    System.out.println("Poruka nema sadržaja");
    return;
  }


}
