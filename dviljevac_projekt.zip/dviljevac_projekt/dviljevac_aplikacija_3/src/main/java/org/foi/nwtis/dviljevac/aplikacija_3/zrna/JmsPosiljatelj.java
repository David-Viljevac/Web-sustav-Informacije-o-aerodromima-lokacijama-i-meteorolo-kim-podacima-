package org.foi.nwtis.dviljevac.aplikacija_3.zrna;

import jakarta.annotation.Resource;
import jakarta.ejb.Stateless;
import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;

/**
 * 
 * Klasa JmsPosiljatelj koja šalje poruku sustavu
 * 
 * @author David Viljevac
 *
 */
@Stateless
public class JmsPosiljatelj {

  public static int brojacPoruka = 0;

  @Resource(mappedName = "jms/nwtis_qf_projekt")
  private ConnectionFactory connectionFactory;
  @Resource(mappedName = "jms/NWTiS_dviljevac")
  private Queue queue;

  /**
   * Metode koja šalje poruku sustavu
   * 
   * @param tekstPoruke
   * @return
   */
  public boolean saljiPoruku(String tekstPoruke) {
    boolean status = true;

    try {
      Connection connection = connectionFactory.createConnection();
      Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
      MessageProducer messageProducer = session.createProducer(queue);
      TextMessage message = session.createTextMessage();


      message.setText(tekstPoruke);
      messageProducer.send(message);
      messageProducer.close();
      connection.close();
    } catch (JMSException ex) {
      ex.printStackTrace();
      status = false;
    }
    return status;
  }
}
