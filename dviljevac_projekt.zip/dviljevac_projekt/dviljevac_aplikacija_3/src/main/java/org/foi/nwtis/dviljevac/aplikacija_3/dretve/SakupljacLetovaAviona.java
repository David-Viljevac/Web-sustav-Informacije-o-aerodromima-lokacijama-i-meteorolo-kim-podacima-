package org.foi.nwtis.dviljevac.aplikacija_3.dretve;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.sql.DataSource;
import org.foi.nwtis.dviljevac.aplikacija_3.slusaci.slusacAplikacije;
import org.foi.nwtis.dviljevac.aplikacija_3.zrna.JmsPosiljatelj;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;
import org.foi.nwtis.rest.klijenti.OSKlijentBP;
import org.foi.nwtis.rest.podaci.LetAviona;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.core.Context;

/**
 * Klasa dretve SakupljacLetovaAviona
 * 
 * @author David Viljevac
 *
 */
public class SakupljacLetovaAviona extends Thread {

  @Context
  ServletContext kontekst;
  Properties konfiguracija;
  int ciklusTrajanja;
  String danOd;
  String danDo;
  long longDanOd;
  long longDanDo;
  String korisnik;
  String lozinka;
  String aerodromiS;
  String[] aerodromi;
  JmsPosiljatelj jms = null;
  DataSource ds = null;

  /**
   * Konstruktor SakupljacLetovaAviona
   * 
   * @param jmsP
   * @param ds
   */

  public SakupljacLetovaAviona(JmsPosiljatelj jmsP, DataSource ds) {
    this.jms = jmsP;
    this.ds = ds;
  }

  /**
   * Override metode start koja dohvaća podatke iz zadanog konteksta
   */
  @Override
  public synchronized void start() {
    kontekst = slusacAplikacije.getKontekst();
    konfiguracija = (Properties) kontekst.getAttribute("konfig");
    ciklusTrajanja = Integer.parseInt(konfiguracija.getProperty("ciklus.trajanje"));

    korisnik = konfiguracija.getProperty("OpenSkyNetwork.korisnik");
    lozinka = konfiguracija.getProperty("OpenSkyNetwork.lozinka");

    super.start();
  }



  /**
   * Override metode run koja dohvaća pojedine podatke iz konteksta odnosno konfiguracije i odrađiva
   * posao dretve i šalje poruke
   */
  @Override
  public void run() {
    danOd = konfiguracija.getProperty("preuzimanje.od");
    danDo = konfiguracija.getProperty("preuzimanje.do");
    longDanOd = pretvoriStringULong(danOd);
    longDanDo = pretvoriStringULong(danDo);
    dohvatiAerodromeZaLetove();
    do {

      long zadnji = dohvatiZadnji();
      if (zadnji >= longDanOd) {
        longDanOd += 86400;
      } else {
        System.out.println("Od vremena = " + longDanOd);
        int pocetak = (int) System.currentTimeMillis();
        int brojLetova = dohvatiPodatke(aerodromi);
        Date datum = new Date(longDanOd * 1000);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String poruka =
            "Na dan " + sdf.format(datum) + " preuzeto ukupno " + brojLetova + " letova aviona";
        System.out.println("Poruka: " + poruka);
        boolean poslana = this.jms.saljiPoruku(poruka);
        int kraj = (int) System.currentTimeMillis();
        int trajanjeSpavanja = ciklusTrajanja * 1000 - (kraj - pocetak);
        if (trajanjeSpavanja <= 0) {
          trajanjeSpavanja = 0;
        }
        System.out.println("Poruka je poslana: " + poslana);
        try {
          Thread.sleep(trajanjeSpavanja);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
        longDanOd += 86400;
      }
    } while (longDanOd < longDanDo);
  }

  /**
   * 
   * Dohvaća podatke prema danom nizu podataka pomoću OSKlijentBP i nwtis_rest_lib-a
   * 
   * @param aerodromi2
   * @return
   */
  private int dohvatiPodatke(String[] aerodromi2) {
    int brojLetova = 0;
    OSKlijentBP osKlijent = new OSKlijentBP(korisnik, lozinka);

    try {
      for (String icao : aerodromi2) {
        long longDanOd = this.longDanOd;
        long longDanDo = longDanOd + 86400;

        var letovi = osKlijent.getDepartures(icao, longDanOd, longDanDo);
        for (LetAviona let : letovi) {
          upisiLet(let);
          brojLetova++;
        }
      }
    } catch (NwtisRestIznimka e) {
    }
    return brojLetova;
  }

  /**
   * Upisuje prosljeđeni let u bazu podataka.
   * 
   * @param let
   */
  private void upisiLet(LetAviona let) {
    int provjera = 0;

    String query =
        "INSERT INTO LETOVI_POLASCI (ICAO24, FIRSTSEEN, ESTDEPARTUREAIRPORT, LASTSEEN,ESTARRIVALAIRPORT, "
            + "CALLSIGN, ESTDEPARTUREAIRPORTHORIZDISTANCE, ESTDEPARTUREAIRPORTVERTDISTANCE, ESTARRIVALAIRPORTHORIZDISTANCE, "
            + "ESTARRIVALAIRPORTVERTDISTANCE, DEPARTUREAIRPORTCANDIDATESCOUNT, ARRIVALAIRPORTCANDIDATESCOUNT, STORED) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    PreparedStatement stat = null;
    Timestamp timestamp = new Timestamp(longDanOd * 1000);
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setString(1, let.getIcao24());
      stat.setInt(2, let.getFirstSeen());
      stat.setString(3, let.getEstDepartureAirport());
      stat.setInt(4, let.getLastSeen());
      stat.setString(5, let.getEstArrivalAirport());
      stat.setString(6, let.getCallsign());
      stat.setInt(7, let.getEstDepartureAirportHorizDistance());
      stat.setInt(8, let.getEstDepartureAirportVertDistance());
      stat.setInt(9, let.getEstArrivalAirportHorizDistance());
      stat.setInt(10, let.getEstArrivalAirportVertDistance());
      stat.setInt(11, let.getDepartureAirportCandidatesCount());
      stat.setInt(12, let.getArrivalAirportCandidatesCount());
      stat.setTimestamp(13, timestamp);
      provjera = stat.executeUpdate();

    } catch (SQLException e) {

    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
  }

  /**
   * Dohvaća zadnji upisani red iz tablice LETOVI_POLASCI i uzima atribut STORED te vraća long tip
   * podatka prema vrijednosti STORED
   * 
   * @return
   */
  private long dohvatiZadnji() {
    long longZadnji = 0;
    ResultSet rezultat = null;

    String query = "SELECT STORED FROM LETOVI_POLASCI ORDER BY ID DESC LIMIT 1; ";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      rezultat = stat.executeQuery();

      if (rezultat.next()) {
        Timestamp storedTimestamp = rezultat.getTimestamp("STORED");
        longZadnji = storedTimestamp.getTime() / 1000;
      }
    } catch (SQLException e) {

    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    return longZadnji;
  }

  /**
   * Metoda koja dohvaća aerodrome za koje se trebaju preuzeti letovi
   * 
   * 
   */

  private void dohvatiAerodromeZaLetove() {
    List<String> aerodromi = new ArrayList();
    this.aerodromi = new String[30];
    String query = "SELECT ICAO FROM AERODROMI_LETOVI WHERE STATUS = ?";

    PreparedStatement stat = null;
    try (Connection con = ds.getConnection()) {
      stat = con.prepareStatement(query);
      stat.setBoolean(1, true);
      ResultSet rs = stat.executeQuery();

      while (rs.next()) {
        aerodromi.add(rs.getString("ICAO"));
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        if (stat != null && !stat.isClosed()) {
          stat.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    int brojac = 0;
    for (String ad : aerodromi) {
      this.aerodromi[brojac] = ad;
      brojac++;
    }
  }

  /**
   * Pretvara datum iz stringa u long
   * 
   * @param vrijeme
   * @return
   */
  private long pretvoriStringULong(String vrijeme) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    Date dan;
    try {
      dan = dateFormat.parse(vrijeme);
      return dan.getTime() / 1000;
    } catch (ParseException e) {
      return 0;
    }
  }

  /**
   * Override interrupt metode
   */
  @Override
  public void interrupt() {
    // TODO Auto-generated method stub
    super.interrupt();
  }
}
