#!/bin/bash

echo "Obrisi kontainer"
docker rm nwtishsqldb_3
echo "Pripremi"
./scripts/pripremiSliku.sh
echo "Pokreni"
./scripts/pokreniSliku.sh
