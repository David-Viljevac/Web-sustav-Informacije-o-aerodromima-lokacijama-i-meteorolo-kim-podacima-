#!/bin/bash

docker build -t nwtishsqldb_3:1.0.0 . &

wait
