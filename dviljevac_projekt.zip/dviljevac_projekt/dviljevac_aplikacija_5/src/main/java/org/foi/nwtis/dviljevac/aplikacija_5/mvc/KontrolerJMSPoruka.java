package org.foi.nwtis.dviljevac.aplikacija_5.mvc;

import java.util.List;
import org.foi.nwtis.dviljevac.aplikacija_5.zrna.SakupljacJmsPoruka;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;

/**
 * Klasa KontrolerJMSPoruka
 * 
 * @author David Viljevac
 *
 */

@Controller
@Path("poruke")
@RequestScoped
public class KontrolerJMSPoruka {
  @Inject
  private Models model;

  @Inject
  SakupljacJmsPoruka sJMS;

  /**
   * GET metoda koja povezuje porukeJms.jsp i stavlja poruke koje su dohvaćene iz sustava u Model.
   */
  @GET
  @View("porukeJms.jsp")
  public void pregledPoruka() {
    List<String> poruke = sJMS.dohvatiPoruke();
    model.put("poruke", poruke);
  }

  /**
   * POST metoda koja služi za brisanje poruka iz reda.
   * 
   * @return
   */
  @POST
  @Path("obrisi")
  @View("porukeJmsObrisi.jsp")
  public Response obrisiPoruke() {
    sJMS.ocistiPoruke();
    return Response.ok().build();
  }
}

