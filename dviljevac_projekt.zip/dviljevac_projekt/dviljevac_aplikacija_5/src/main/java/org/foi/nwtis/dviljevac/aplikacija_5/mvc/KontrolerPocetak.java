
package org.foi.nwtis.dviljevac.aplikacija_5.mvc;

import jakarta.enterprise.context.RequestScoped;
import jakarta.mvc.Controller;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

/**
 * Klasa KontrolerPocetak
 * 
 * @author David Viljevac
 */
@Controller
@Path("pocetak")
@RequestScoped
public class KontrolerPocetak {

  @GET
  @View("index.jsp")
  public void pocetak() {}

}
