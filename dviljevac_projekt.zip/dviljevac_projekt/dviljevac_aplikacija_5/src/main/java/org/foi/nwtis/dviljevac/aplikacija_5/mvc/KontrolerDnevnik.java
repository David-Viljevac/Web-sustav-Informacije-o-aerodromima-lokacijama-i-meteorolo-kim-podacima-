
package org.foi.nwtis.dviljevac.aplikacija_5.mvc;

import org.foi.nwtis.dviljevac.aplikacija_5.rest.RestKlijentDnevnik;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;

/**
 * Klasa KontrolerDnevnik
 * 
 * @author David Viljevac
 */
@Controller
@Path("dnevnik")
@RequestScoped
public class KontrolerDnevnik {
  @Inject
  private Models model;

  @GET
  @View("dnevnik.jsp")
  public void pocetak() {}

  /**
   * GET metoda koja povezuje rest servis za dnevnik te stavlja zapise iz dnevnika u model.
   * 
   * @param vrsta
   * @param odBroja
   * @param broj
   */
  @GET
  @Path("pregled")
  @View("dnevnik.jsp")
  public void getZapisiDnevnik(@QueryParam("vrsta") String vrsta,
      @QueryParam("odBroja") @DefaultValue("0") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {
    try {
      RestKlijentDnevnik rcd = new RestKlijentDnevnik();
      var dk = rcd.getZapisiDnevnik(vrsta, odBroja, broj);
      model.put("dnevnik", dk);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
