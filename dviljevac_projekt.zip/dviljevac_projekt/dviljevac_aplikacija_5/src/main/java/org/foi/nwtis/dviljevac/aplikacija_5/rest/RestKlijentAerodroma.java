package org.foi.nwtis.dviljevac.aplikacija_5.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.Aerodrom;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.AerodromiUdaljenostKlasa;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.AerodromiUdaljenostKlasa2;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.AerodromiUdaljenostKlasaOdDo;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.UdaljenostAerodromDrzava;
import org.foi.nwtis.dviljevac.aplikacija_5.slusaci.slusacAplikacije;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

/**
 * Klasa RestKlijentAerodroma
 * 
 * @author David Viljevac
 *
 */
public class RestKlijentAerodroma {

  /**
   * Konstruktor klase.
   */
  public RestKlijentAerodroma() {

  }

  /**
   * Metoda koja dohvaća sve aerodrome.
   * 
   * @param odBroja
   * @param broj
   * @return
   */
  public List<Aerodrom> getAerodromi(int odBroja, int broj, String traziNaziv, String traziDrzavu) {
    RestKKlijent rc = new RestKKlijent();
    Aerodrom[] json_Aerodromi = rc.getAerodromi(odBroja, broj, traziNaziv, traziDrzavu);
    List<Aerodrom> aerodromi;
    if (json_Aerodromi == null) {
      aerodromi = new ArrayList<>();
    } else {
      aerodromi = Arrays.asList(json_Aerodromi);
    }
    rc.close();
    return aerodromi;
  }

  /**
   * Metoda koja dohvaća samo jedan aerodrom.
   * 
   * @param icao
   * @return
   */
  public Aerodrom getAerodrom(String icao) {
    RestKKlijent rc = new RestKKlijent();
    Aerodrom k = rc.getAerodrom(icao);
    rc.close();
    return k;
  }

  /**
   * Metoda koja dohvaća udaljenost aerodroma po državama
   * 
   * @param icaoOd
   * @param icaoDo
   * @return
   */
  public List<UdaljenostAerodromDrzava> getUdaljenosti(String icaoOd, String icaoDo) {
    RestKKlijent rc = new RestKKlijent();
    UdaljenostAerodromDrzava[] u = rc.getUdaljenosti(icaoOd, icaoDo);
    rc.close();
    return Arrays.asList(u);
  }

  /**
   * Metoda koja dohvaća udaljenost od aerodroma do aerodroma.
   * 
   * @param icaoOd
   * @param odBroja
   * @param broj
   * @return
   */
  public AerodromiUdaljenostKlasa getUdaljenostiOdDo(String icaoOd, String icaoDo) {
    RestKKlijent rc = new RestKKlijent();
    AerodromiUdaljenostKlasa u = rc.getUdaljenostiOdDo(icaoOd, icaoDo);
    rc.close();
    return u;
  }

  /**
   * Metoda koja dohvaća udaljenost aerodroma i aerodrome od do uz udaljenost manju od udaljenosti
   * izmedu dvaju zadanih aerodroma
   * 
   * @param icaoOd
   * @param icaoDo
   * @return
   */
  public AerodromiUdaljenostKlasaOdDo getUdaljenostiOdDoManja(String icaoOd, String icaoDo) {
    RestKKlijent rc = new RestKKlijent();
    AerodromiUdaljenostKlasaOdDo u = rc.getUdaljenostiOdDoManja(icaoOd, icaoDo);
    rc.close();
    return u;
  }

  /**
   * Metoda koja dohvaća udaljenosti aerodromai aerodrome uz udaljenost manju od udaljenosti od km i
   * u zadanoj drzavi
   * 
   * @param icaoOd
   * @param drzava
   * @param km
   * @return
   */
  public AerodromiUdaljenostKlasaOdDo getUdaljenostiUDrzaviIspodKm(String icaoOd, String drzava,
      String km) {
    RestKKlijent rc = new RestKKlijent();
    AerodromiUdaljenostKlasaOdDo u = rc.getUdaljenostiUDrzaviIspodKm(icaoOd, drzava, km);
    rc.close();
    return u;
  }

  /**
   * Klasa RestKKlijent
   * 
   * @author David Viljevac
   *
   */
  static class RestKKlijent {

    /**
     * Varijabla konfiguracije
     */
    private final Properties konfiguracija;
    /**
     * Varijabla webTarget
     */
    private final WebTarget webTarget;
    /**
     * Varijabla client
     */
    private final Client client;
    /**
     * Varijabla BASE_URI
     */
    private final String BASE_URI;

    /**
     * Konstruktor klase
     */
    public RestKKlijent() {
      ServletContext kontekst = slusacAplikacije.getKontekst();
      Properties konfig = (Properties) kontekst.getAttribute("konfig");
      this.konfiguracija = konfig;
      this.BASE_URI = (String) konfiguracija.getProperty("adresa.app2");
      this.client = ClientBuilder.newClient();
      this.webTarget = client.target(BASE_URI).path("aerodromi");
    }

    /**
     * Metoda koja povezuje dohvaćanje svih aerodroma i API za to.
     * 
     * @param odBroja
     * @param broj
     * @return
     * @throws ClientErrorException
     * @see RestKlijentAerodroma
     */
    public Aerodrom[] getAerodromi(int odBroja, int broj, String traziNaziv, String traziDrzavu)
        throws ClientErrorException {
      WebTarget resource = webTarget;

      resource = resource.queryParam("odBroja", new Object[] {odBroja});
      resource = resource.queryParam("broj", new Object[] {broj});
      if (traziNaziv != null) {
        resource = resource.queryParam("traziNaziv", new Object[] {traziNaziv});
        System.out.println(resource);
      }
      if (traziDrzavu != null) {
        resource = resource.queryParam("traziDrzavu", new Object[] {traziDrzavu});
      }
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      Aerodrom[] aerodromi = gson.fromJson(request.get(String.class), Aerodrom[].class);

      return aerodromi;
    }

    /**
     * Metoda koja povezuje dohvaćanje jednog aerodroma i API za to.
     * 
     * @param icao
     * @return
     * @throws ClientErrorException
     * @see RestKlijentAerodroma
     */
    public Aerodrom getAerodrom(String icao) throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icao}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      Aerodrom aerodrom = gson.fromJson(request.get(String.class), Aerodrom.class);
      return aerodrom;
    }

    /**
     * Metoda koja povezuje dohvaćanje udaljenosti po državama i API za to.
     * 
     * @param icaoOd
     * @param icaoDo
     * @return
     * @throws ClientErrorException
     * @see RestKlijentAerodroma
     */
    public UdaljenostAerodromDrzava[] getUdaljenosti(String icaoOd, String icaoDo)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource =
          resource.path(java.text.MessageFormat.format("{0}/{1}", new Object[] {icaoOd, icaoDo}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      UdaljenostAerodromDrzava[] udaljenosti =
          gson.fromJson(request.get(String.class), UdaljenostAerodromDrzava[].class);
      return udaljenosti;
    }

    /**
     * Metoda koja dohvaća udaljenost i oba aerodroma
     * 
     * @param icaoOd
     * @param icaoDo
     * @return
     * @throws ClientErrorException
     */
    public AerodromiUdaljenostKlasa getUdaljenostiOdDo(String icaoOd, String icaoDo)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icaoOd}));
      resource = resource.path("izracunaj");
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icaoDo}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      JsonObject jsonObject = gson.fromJson(request.get(String.class), JsonObject.class);



      AerodromiUdaljenostKlasa udaljenost = new AerodromiUdaljenostKlasa();
      List<Aerodrom> aerodromi = new ArrayList<>();
      JsonArray aerodromiJsonArray = jsonObject.getAsJsonArray("aerodromi");
      for (JsonElement aerodromJsonElement : aerodromiJsonArray) {
        Aerodrom aerodrom = gson.fromJson(aerodromJsonElement, Aerodrom.class);
        aerodromi.add(aerodrom);
      }
      udaljenost.setAerodromi(aerodromi);
      udaljenost.setUdaljenost(jsonObject.get("odgovorPosluzitelja").getAsFloat());
      return udaljenost;
    }

    /**
     * Metoda koja vraća aerodrome i udaljenosti manje od udaljenost izmedu odbranog aerodroma do.
     * 
     * @param icaoOd
     * @param icaoDo
     * @return
     * @throws ClientErrorException
     */
    public AerodromiUdaljenostKlasaOdDo getUdaljenostiOdDoManja(String icaoOd, String icaoDo)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icaoOd}));
      resource = resource.path("udaljenost1");
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icaoDo}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      JsonObject jsonObject = gson.fromJson(request.get(String.class), JsonObject.class);



      AerodromiUdaljenostKlasaOdDo udaljenost = new AerodromiUdaljenostKlasaOdDo();
      List<AerodromiUdaljenostKlasa2> aerodromi = new ArrayList<>();
      JsonArray aerodromiJsonArray = jsonObject.getAsJsonArray("aerodromiIcaoDoSUdaljenostima");
      for (JsonElement aerodromJsonElement : aerodromiJsonArray) {
        AerodromiUdaljenostKlasa2 aer2 = new AerodromiUdaljenostKlasa2();
        Aerodrom aerodrom =
            gson.fromJson(aerodromJsonElement.getAsJsonObject().get("aerodrom"), Aerodrom.class);
        float uda = gson.fromJson(aerodromJsonElement.getAsJsonObject().get("udaljenostdoIcaoDo"),
            Float.class);
        aer2.setAerodrom(aerodrom);
        aer2.setUdaljenost(uda);
        aerodromi.add(aer2);
      }
      List<Aerodrom> aer = new ArrayList<>();
      JsonArray aerodromiJsonArray2 = jsonObject.getAsJsonArray("aerodromIcaoOd");
      for (JsonElement aerodromJsonElement : aerodromiJsonArray2) {
        Aerodrom aerodrom = gson.fromJson(aerodromJsonElement, Aerodrom.class);
        aer.add(aerodrom);
      }
      udaljenost.setAerodromi(aerodromi);
      udaljenost.setAerodromiDo(aer);
      return udaljenost;
    }

    /**
     * Metoda koja dohvaća aerodrome i udaljenosti aerodroma koji su u zadanoj drzavi i ispod
     * zadanih km
     * 
     * @param icaoOd
     * @param drzava
     * @param km
     * @return
     * @throws ClientErrorException
     */
    public AerodromiUdaljenostKlasaOdDo getUdaljenostiUDrzaviIspodKm(String icaoOd, String drzava,
        String km) throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icaoOd}));
      resource = resource.path("udaljenost2");
      resource = resource.queryParam("drzava", new Object[] {drzava});
      resource = resource.queryParam("km", new Object[] {km});
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      JsonObject jsonObject = gson.fromJson(request.get(String.class), JsonObject.class);



      AerodromiUdaljenostKlasaOdDo udaljenost = new AerodromiUdaljenostKlasaOdDo();
      List<AerodromiUdaljenostKlasa2> aerodromi = new ArrayList<>();
      JsonArray aerodromiJsonArray = jsonObject.getAsJsonArray("aerodromiIcaoDoSUdaljenostima");
      for (JsonElement aerodromJsonElement : aerodromiJsonArray) {
        AerodromiUdaljenostKlasa2 aer2 = new AerodromiUdaljenostKlasa2();
        Aerodrom aerodrom =
            gson.fromJson(aerodromJsonElement.getAsJsonObject().get("aerodrom"), Aerodrom.class);
        float uda = gson.fromJson(aerodromJsonElement.getAsJsonObject().get("udaljenostdoIcaoDo"),
            Float.class);
        aer2.setAerodrom(aerodrom);
        aer2.setUdaljenost(uda);
        aerodromi.add(aer2);
      }
      List<Aerodrom> aer = new ArrayList<>();
      JsonArray aerodromiJsonArray2 = jsonObject.getAsJsonArray("aerodromIcaoOd");
      for (JsonElement aerodromJsonElement : aerodromiJsonArray2) {
        Aerodrom aerodrom = gson.fromJson(aerodromJsonElement, Aerodrom.class);
        aer.add(aerodrom);
      }
      udaljenost.setAerodromi(aerodromi);
      udaljenost.setAerodromiDo(aer);
      return udaljenost;
    }

    /**
     * Metoda koja zatvara klijentsku stranu.
     */
    public void close() {
      client.close();
    }
  }

}
