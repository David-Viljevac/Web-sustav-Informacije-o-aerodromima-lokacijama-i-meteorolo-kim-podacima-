package org.foi.nwtis.dviljevac.aplikacija_5.podaci;


/**
 * 
 * @author David Viljevac
 *
 */
public record StatusOdgovor(int status, String opis) {

}
