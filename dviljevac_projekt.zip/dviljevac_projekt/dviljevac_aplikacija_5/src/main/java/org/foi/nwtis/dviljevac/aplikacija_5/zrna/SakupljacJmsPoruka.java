package org.foi.nwtis.dviljevac.aplikacija_5.zrna;

import java.util.ArrayList;
import java.util.List;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.enterprise.inject.Default;

/**
 * Klasa SakupljacJmsPoruka
 * 
 * @author David Viljevac
 *
 */
@Default
@Singleton
@Startup
public class SakupljacJmsPoruka {
  List<String> kolekcijaPoruka = new ArrayList<String>();

  /**
   * Vraća kolekciju poruka
   * 
   * @return
   */
  public List<String> dohvatiPoruke() {
    return this.kolekcijaPoruka;
  }

  /**
   * Dodaje poruku u kolekciju poruka
   * 
   * @param poruka
   */
  public void postaviPoruku(String poruka) {
    this.kolekcijaPoruka.add(poruka);
  }

  /**
   * Briše kolekciju poruka
   */
  public void ocistiPoruke() {
    this.kolekcijaPoruka = new ArrayList<String>();
  }
}
