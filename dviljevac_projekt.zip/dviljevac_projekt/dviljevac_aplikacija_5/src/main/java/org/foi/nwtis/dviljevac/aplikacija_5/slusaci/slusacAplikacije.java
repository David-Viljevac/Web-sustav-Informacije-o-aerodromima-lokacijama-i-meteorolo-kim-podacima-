package org.foi.nwtis.dviljevac.aplikacija_5.slusaci;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

/**
 * Klasa slusacAplikacije
 * 
 * @author David Viljevac
 *
 */
public class slusacAplikacije implements ServletContextListener {

  private static ServletContext context;
  private String adresa = "";
  private int mreznaVrata = 0;
  private String komanda = "STATUS";
  private String statusPosluzitelja = "false";

  @Override
  public void contextInitialized(ServletContextEvent sce) {
    context = sce.getServletContext();
    Properties konfiguracija = new Properties();
    String konfig = context.getInitParameter("konfiguracija");
    String putanja = context.getRealPath("/WEB-INF") + java.io.File.separator;
    try {
      FileInputStream fis = new FileInputStream(putanja + konfig);
      konfiguracija.loadFromXML(fis);
      fis.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    this.adresa = (String) konfiguracija.getProperty("adresa");
    this.mreznaVrata = Integer.parseInt(konfiguracija.getProperty("mreznaVrata"));
    provjeriStatusPosluzitelja();
    konfiguracija.setProperty("statusPosluzitelja", this.statusPosluzitelja);
    context.setAttribute("konfig", konfiguracija);
  }

  public static ServletContext getKontekst() {
    return context;

  }



  @Override
  public void contextDestroyed(ServletContextEvent sce) {

    ServletContextListener.super.contextDestroyed(sce);
  }


  /**
   * Metoda provjere statusa posluzitelja.
   */
  public void provjeriStatusPosluzitelja() {
    try {
      var mreznaUticnica = new Socket(this.adresa, this.mreznaVrata);
      var citac = new BufferedReader(
          new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
      var pisac = new BufferedWriter(
          new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));

      var poruka = new StringBuilder();
      pisac.write(komanda);
      pisac.flush();
      mreznaUticnica.shutdownOutput();
      while (true) {
        var red = citac.readLine();
        if (red == null) {
          break;
        }
        Logger.getGlobal().log(Level.INFO, red);
        poruka.append(red);
        if (red.toString().contains("0")) {
          this.statusPosluzitelja = "false";
        } else {
          this.statusPosluzitelja = "true";
        }
      }
      mreznaUticnica.shutdownInput();
      mreznaUticnica.close();
    } catch (IOException e) {
      e.printStackTrace();
      return;
    }
  }
}
