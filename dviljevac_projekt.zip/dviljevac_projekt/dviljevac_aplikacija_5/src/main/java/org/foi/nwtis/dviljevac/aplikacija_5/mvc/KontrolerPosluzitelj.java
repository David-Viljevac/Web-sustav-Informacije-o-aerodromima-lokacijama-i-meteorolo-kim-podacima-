
package org.foi.nwtis.dviljevac.aplikacija_5.mvc;

import org.foi.nwtis.dviljevac.aplikacija_5.podaci.StatusOdgovor;
import org.foi.nwtis.dviljevac.aplikacija_5.rest.RestKlijentPosluzitelj;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;

/**
 * Klasa KontrolerPosluzitelj
 * 
 * @author David Viljevac
 */
@Controller
@Path("posluzitelj")
@RequestScoped
public class KontrolerPosluzitelj {
  @Inject
  private Models model;

  @GET
  @View("posluzitelj.jsp")
  public void pocetak() {}

  /**
   * POST metoda koja koristi rest servis posluzitelja te stavlja komandu i podatke odgovora u
   * model.
   * 
   * @param komanda
   */
  @POST
  @Path("komanda")
  @View("posluzitelj.jsp")
  public void getKomandaInfo(@FormParam("komanda") String komanda) {
    try {
      RestKlijentPosluzitelj rcp = new RestKlijentPosluzitelj();
      StatusOdgovor so = rcp.getStatusOdgovor(komanda);

      model.put("komanda", komanda);
      model.put("status", so);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
