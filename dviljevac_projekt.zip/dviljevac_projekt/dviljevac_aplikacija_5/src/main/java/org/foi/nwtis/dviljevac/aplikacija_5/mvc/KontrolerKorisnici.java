
package org.foi.nwtis.dviljevac.aplikacija_5.mvc;

import org.foi.nwtis.dviljevac.aplikacija_4.ws.WsKorisnici.endpoint.Korisnici;
import org.foi.nwtis.dviljevac.aplikacija_4.ws.WsKorisnici.endpoint.Korisnik;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.xml.ws.WebServiceRef;

/**
 * Klasa KontrolerKorisnici
 * 
 * @author David Viljevac
 */
@Controller
@Path("korisnici")
@RequestScoped
public class KontrolerKorisnici {

  @GET
  @View("korisnici.jsp")
  public void pocetak() {}

  @WebServiceRef(wsdlLocation = "http://localhost:8080/dviljevac_aplikacija_4/korisnici?wsdl")
  private Korisnici service;

  @Inject
  private Models model;

  /**
   * GET metoda koja prikazuje sve korisnike u bazi podataka koji se mogu filtrirati prema imenu i
   * prezimenu
   * 
   * @param korisnik
   * @param lozinka
   * @param traziImeKorisnika
   * @param traziPrezimeKorisnika
   */
  @GET
  @Path("pregled")
  @View("korisniciPregled.jsp")
  public Response getKorisnici(@QueryParam("traziImeKorisnika") String traziImeKorisnika,
      @QueryParam("traziPrezimeKorisnika") String traziPrezimeKorisnika,
      @Context HttpServletRequest request) {
    HttpSession sesija = request.getSession();
    String korisnik = (String) sesija.getAttribute("korIme");
    String lozinka = (String) sesija.getAttribute("lozinka");
    try {
      if (traziImeKorisnika == null) {
        traziImeKorisnika = "";
      }
      if (traziPrezimeKorisnika == null) {
        traziPrezimeKorisnika = "";
      }
      var port = service.getWsKorisniciPort();
      var korisnici =
          port.dajKorisnike(korisnik, lozinka, traziImeKorisnika, traziPrezimeKorisnika);
      model.put("korisnici", korisnici);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return Response.ok().build();
  }

  @GET
  @Path("registracija")
  @View("korisniciRegistracija.jsp")
  public Response registracijaKorisnik() {
    return Response.ok().build();
  }


  /**
   * POST metoda za registriranje korisnika koja koristi metodu WsKorisnici
   * 
   * @param korIme
   * @param lozinka
   * @param ime
   * @param prezime
   * @param request
   * @return
   */
  @POST
  @Path("registriran")
  public Response regKorisnik(@FormParam("korIme") String korIme,
      @FormParam("lozinka") String lozinka, @FormParam("ime") String ime,
      @FormParam("prezime") String prezime, @Context HttpServletRequest request) {
    HttpSession sesija = request.getSession();
    String korisnik = (String) sesija.getAttribute("korIme");
    String lozinkaP = (String) sesija.getAttribute("lozinka");
    Korisnik k = new Korisnik();
    k.setIme(ime);
    k.setKorIme(korIme);
    k.setLozinka(lozinka);
    k.setPrezime(prezime);
    var port = service.getWsKorisniciPort();
    var provjera1 = port.dajKorisnika(korisnik, lozinkaP, korIme);
    if (provjera1 != null) {
      return Response.serverError().build();
    }
    var provjera = port.dodajKorisnika(k);
    if (provjera) {
      String message = "Korisnik registriran uspješno";

      return Response.ok().build();
    } else {
      String errorMessage = "Došlo je do pogreške prilikom registracije korisnika";
      return Response.serverError().entity(errorMessage).build();
    }

  }

  @GET
  @Path("prijava")
  @View("korisniciPrijava.jsp")
  public Response prijavaKorisnik() {

    return Response.ok().build();
  }

  /**
   * POST metoda koja se koristi za prijavljivanje korisnika prema paremetrima uz provjeru iz baze
   * podataka te koristi WsKorisnici metodu. Zapisuje prijavljenog korisnika odnosno korisnicko ime
   * u sesiju
   * 
   * @param korIme
   * @param lozinka
   * @param request
   * @return
   */
  @POST
  @Path("prijavljen")
  public Response priKorisnik(@FormParam("korIme") String korIme,
      @FormParam("lozinka") String lozinka, @Context HttpServletRequest request) {

    var port = service.getWsKorisniciPort();

    boolean provjera = port.autentikacijaKorisnika(korIme, lozinka);
    if (provjera) {
      HttpSession session = request.getSession();
      session.setAttribute("korIme", korIme);
      session.setAttribute("lozinka", lozinka);
      return Response.ok().build();
    } else {
      return Response.serverError().build();
    }
  }
}
