package org.foi.nwtis.dviljevac.aplikacija_5.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.DnevnikKlasa;
import org.foi.nwtis.dviljevac.aplikacija_5.slusaci.slusacAplikacije;
import com.google.gson.Gson;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

/**
 * Klasa RestKlijentDnevnik
 * 
 * @author David Viljevac
 *
 */
public class RestKlijentDnevnik {

  /**
   * Konstruktor klase.
   */
  public RestKlijentDnevnik() {

  }

  /**
   * Metoda dohvaćanja zapisa dnevnika prema vrsti.
   * 
   * @param vrsta
   * @param odBroja
   * @param broj
   * @return
   */
  public List<DnevnikKlasa> getZapisiDnevnik(String vrsta, int odBroja, int broj) {
    List<DnevnikKlasa> dk = new ArrayList();

    RestKKlijent rc = new RestKKlijent();
    var zapisi = rc.getZapisiDnevnik(vrsta, odBroja, broj);
    dk = Arrays.asList(zapisi);
    rc.close();
    return dk;
  }

  /**
   * Klasa RestKKlijent
   * 
   * @author David Viljevac
   *
   */
  static class RestKKlijent {

    /**
     * Varijabla konfiguracije
     */
    private final Properties konfiguracija;
    /**
     * Varijabla webTarget
     */
    private final WebTarget webTarget;
    /**
     * Varijabla client
     */
    private final Client client;
    /**
     * Varijabla BASE_URI
     */
    private final String BASE_URI;

    /**
     * Konstruktor klase
     */
    public RestKKlijent() {
      ServletContext kontekst = slusacAplikacije.getKontekst();
      Properties konfig = (Properties) kontekst.getAttribute("konfig");
      this.konfiguracija = konfig;
      this.BASE_URI = (String) konfiguracija.getProperty("adresa.app2");
      this.client = ClientBuilder.newClient();
      this.webTarget = client.target(BASE_URI).path("dnevnik");
    }

    /**
     * Metoda dohvaćanja zapisa iz dnevnika prema vrsti.
     * 
     * @param vrsta
     * @param odBroja
     * @param broj
     * @return
     */
    public DnevnikKlasa[] getZapisiDnevnik(String vrsta, int odBroja, int broj) {
      WebTarget resource = webTarget;

      resource = resource.queryParam("odBroja", new Object[] {odBroja});
      resource = resource.queryParam("broj", new Object[] {broj});
      resource = resource.queryParam("vrsta", new Object[] {vrsta});
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      DnevnikKlasa[] udaljenosti = gson.fromJson(request.get(String.class), DnevnikKlasa[].class);
      return udaljenosti;
    }

    /**
     * Metoda koja zatvara klijentsku stranu.
     */
    public void close() {
      client.close();
    }
  }

}
