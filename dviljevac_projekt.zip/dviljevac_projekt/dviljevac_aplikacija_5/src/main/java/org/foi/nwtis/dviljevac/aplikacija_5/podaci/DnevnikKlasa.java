package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public class DnevnikKlasa {
  private String metoda;
  private String putanja;
  private String adresa;
  private String vrsta;

  public DnevnikKlasa(String metoda, String putanja, String adresa, String vrsta) {
    super();
    this.metoda = metoda;
    this.putanja = putanja;
    this.adresa = adresa;
    this.vrsta = vrsta;
  }

  public String getMetoda() {
    return metoda;
  }

  public void setMetoda(String metoda) {
    this.metoda = metoda;
  }

  public String getPutanja() {
    return putanja;
  }

  public void setPutanja(String putanja) {
    this.putanja = putanja;
  }

  public String getAdresa() {
    return adresa;
  }

  public void setAdresa(String adresa) {
    this.adresa = adresa;
  }

  public String getVrsta() {
    return vrsta;
  }

  public void setVrsta(String vrsta) {
    this.vrsta = vrsta;
  }


}
