package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

/**
 * 
 * @author David Viljevac
 *
 */
public record Udaljenost(String drzava, float km) {

}
