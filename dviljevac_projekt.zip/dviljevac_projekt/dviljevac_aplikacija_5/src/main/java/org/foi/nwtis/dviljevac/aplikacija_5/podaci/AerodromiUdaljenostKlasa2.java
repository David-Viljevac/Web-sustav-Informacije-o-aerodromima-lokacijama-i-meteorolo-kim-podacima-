package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

/**
 * 
 * @author David Viljevac
 *
 */

public class AerodromiUdaljenostKlasa2 {

  private Aerodrom aerodromi;
  private float udaljenost;

  public AerodromiUdaljenostKlasa2(Aerodrom aerodromi, float udaljenost) {
    super();
    this.aerodromi = aerodromi;
    this.udaljenost = udaljenost;
  }

  public AerodromiUdaljenostKlasa2() {
    // TODO Auto-generated constructor stub
  }

  public Aerodrom getAerodrom() {
    return aerodromi;
  }

  public void setAerodrom(Aerodrom aerodromi) {
    this.aerodromi = aerodromi;
  }

  public float getUdaljenost() {
    return udaljenost;
  }

  public void setUdaljenost(float udaljenost) {
    this.udaljenost = udaljenost;
  }



}
