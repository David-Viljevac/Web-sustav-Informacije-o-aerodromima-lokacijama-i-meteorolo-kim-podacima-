package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

import java.util.List;

/**
 * 
 * @author David Viljevac
 *
 */

public class AerodromiUdaljenostKlasa {

  private List<Aerodrom> aerodromi;
  private float udaljenost;

  public AerodromiUdaljenostKlasa(List<Aerodrom> aerodromi, float udaljenost) {
    super();
    this.aerodromi = aerodromi;
    this.udaljenost = udaljenost;
  }

  public AerodromiUdaljenostKlasa() {
    // TODO Auto-generated constructor stub
  }

  public List<Aerodrom> getAerodromi() {
    return aerodromi;
  }

  public void setAerodromi(List<Aerodrom> aerodromi) {
    this.aerodromi = aerodromi;
  }

  public float getUdaljenost() {
    return udaljenost;
  }

  public void setUdaljenost(float udaljenost) {
    this.udaljenost = udaljenost;
  }



}
