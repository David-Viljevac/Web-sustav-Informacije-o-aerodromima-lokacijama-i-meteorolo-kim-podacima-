package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

import java.util.List;

/**
 * 
 * @author David Viljevac
 *
 */

public class AerodromiUdaljenostKlasaOdDo {

  private List<AerodromiUdaljenostKlasa2> aerodromi;
  private List<Aerodrom> aerodromiDo;

  public AerodromiUdaljenostKlasaOdDo(List<AerodromiUdaljenostKlasa2> aerodromi,
      List<Aerodrom> aerodromiDo) {
    super();
    this.aerodromi = aerodromi;
    this.aerodromiDo = aerodromiDo;
  }

  public AerodromiUdaljenostKlasaOdDo() {
    // TODO Auto-generated constructor stub
  }

  public List<AerodromiUdaljenostKlasa2> getAerodromi() {
    return aerodromi;
  }

  public void setAerodromi(List<AerodromiUdaljenostKlasa2> aerodromi) {
    this.aerodromi = aerodromi;
  }

  public List<Aerodrom> getAerodromiDo() {
    return aerodromiDo;
  }

  public void setAerodromiDo(List<Aerodrom> aerodromiDo) {
    this.aerodromiDo = aerodromiDo;
  }
}
