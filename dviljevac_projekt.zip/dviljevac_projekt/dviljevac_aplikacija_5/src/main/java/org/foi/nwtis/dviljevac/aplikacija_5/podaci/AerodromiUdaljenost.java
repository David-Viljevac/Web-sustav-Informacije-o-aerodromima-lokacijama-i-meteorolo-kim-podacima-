package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

import java.util.List;

/**
 * 
 * @author David Viljevac
 *
 */
public record AerodromiUdaljenost(List<Aerodrom> aerodromi, float udaljenost) {

}
