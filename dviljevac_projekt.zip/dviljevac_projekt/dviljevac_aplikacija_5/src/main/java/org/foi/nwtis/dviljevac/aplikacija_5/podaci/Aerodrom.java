package org.foi.nwtis.dviljevac.aplikacija_5.podaci;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author David Viljevac
 * @version 2.3.0
 */
@AllArgsConstructor()
public class Aerodrom {

  @Getter
  @Setter
  private String icao;
  @Getter
  @Setter
  private String naziv;
  @Getter
  @Setter
  private String drzava;
  @Getter
  @Setter
  private Lokacija lokacija;

  public Aerodrom() {}
}
