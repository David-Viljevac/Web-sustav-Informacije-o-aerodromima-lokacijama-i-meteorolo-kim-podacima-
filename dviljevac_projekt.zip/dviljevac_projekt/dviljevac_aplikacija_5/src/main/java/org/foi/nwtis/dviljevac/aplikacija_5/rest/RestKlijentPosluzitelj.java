package org.foi.nwtis.dviljevac.aplikacija_5.rest;

import java.util.Properties;
import org.foi.nwtis.dviljevac.aplikacija_5.podaci.StatusOdgovor;
import org.foi.nwtis.dviljevac.aplikacija_5.slusaci.slusacAplikacije;
import com.google.gson.Gson;
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

/**
 * Klasa RestKlijentAerodroma
 * 
 * @author David Viljevac
 *
 */
public class RestKlijentPosluzitelj {

  /**
   * Konstruktor klase.
   */
  public RestKlijentPosluzitelj() {

  }

  /**
   * Metoda dohvaćanja odgovora sa rest servisa za neku komandu
   * 
   * @param komanda
   * @return
   */
  public StatusOdgovor getStatusOdgovor(String komanda) {
    StatusOdgovor so = null;

    RestKKlijent rc = new RestKKlijent();
    so = rc.getStatusOdgovor(komanda);
    rc.close();
    return so;
  }

  /**
   * Klasa RestKKlijent
   * 
   * @author David Viljevac
   *
   */
  static class RestKKlijent {

    /**
     * Varijabla konfiguracije
     */
    private final Properties konfiguracija;
    /**
     * Varijabla webTarget
     */
    private final WebTarget webTarget;
    /**
     * Varijabla client
     */
    private final Client client;
    /**
     * Varijabla BASE_URI
     */
    private final String BASE_URI;

    /**
     * Konstruktor klase
     */
    public RestKKlijent() {
      ServletContext kontekst = slusacAplikacije.getKontekst();
      Properties konfig = (Properties) kontekst.getAttribute("konfig");
      this.konfiguracija = konfig;
      this.BASE_URI = (String) konfiguracija.getProperty("adresa.app2");
      this.client = ClientBuilder.newClient();
      this.webTarget = client.target(BASE_URI).path("nadzor");
    }

    /**
     * Metoda dohvaćanja i povezivanja API-a za vraćanje odgovora sa servisa.
     * 
     * @param komanda
     * @return
     */
    public StatusOdgovor getStatusOdgovor(String komanda) {
      WebTarget resource = webTarget;

      if (komanda.contains("INFO")) {
        String[] komandaInfo = komanda.split(" ");
        resource = resource.path(java.text.MessageFormat.format("{0}/{1}",
            new Object[] {komandaInfo[0], komandaInfo[1]}));
      } else if (komanda.contains("STATUS")) {

      } else {
        resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {komanda}));
      }

      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      String response = request.get(String.class);
      if (response.isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      StatusOdgovor so = gson.fromJson(response, StatusOdgovor.class);
      return so;
    }

    /**
     * Metoda koja zatvara klijentsku stranu.
     */
    public void close() {
      client.close();
    }
  }

}
