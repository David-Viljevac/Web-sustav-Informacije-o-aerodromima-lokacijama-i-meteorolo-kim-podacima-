
package org.foi.nwtis.dviljevac.aplikacija_5.mvc;

import org.foi.nwtis.dviljevac.aplikacija_4.ws.WsAerodromi.endpoint.Aerodromi;
import org.foi.nwtis.dviljevac.aplikacija_5.rest.RestKlijentAerodroma;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.xml.ws.WebServiceRef;

/**
 * Klasa KontrolerAerodroma
 * 
 * @author David Viljevac
 */
@Controller
@Path("aerodromi")
@RequestScoped
public class KontrolerAerodromi {

  @GET
  @View("aerodromi.jsp")
  public void pocetak() {}

  @WebServiceRef(wsdlLocation = "http://localhost:8080/dviljevac_aplikacija_4/aerodromi?wsdl")
  private Aerodromi service;

  @Inject
  private Models model;

  /**
   * GET metoda koja povezuje aerodromiPregled.jsp i postavlja potrebne podatke unutar Model klase
   * (putanja .../pregled).
   * 
   * @param odBroja
   * @param broj
   */
  @GET
  @Path("pregled")
  @View("aerodromiPregled.jsp")
  public void getAerodromi(@QueryParam("odBroja") @DefaultValue("0") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj, @QueryParam("traziNaziv") String traziNaziv,
      @QueryParam("traziDrzavu") String traziDrzavu) {
    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();

      var aerodromi = rca.getAerodromi(odBroja, broj, traziNaziv, traziDrzavu);
      model.put("aerodromi", aerodromi);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * POST metoda za dodavanje aerodroma za preuzimanje letova u bazu podataka prema WsAerodromi
   * metodi
   * 
   * @param icao
   * @param request
   * @return
   */
  @POST
  @Path("dodajAerodromZaLetove/{icao}")
  @View("dodajAerodromZaLetove.jsp")
  public Response dodajAerodromZaLet(@PathParam("icao") String icao,
      @Context HttpServletRequest request) {
    HttpSession sesija = request.getSession();
    String korisnik = (String) sesija.getAttribute("korIme");
    String lozinka = (String) sesija.getAttribute("lozinka");
    try {

      var port = service.getWsAerodromiPort();
      var provjera = port.dodajAerodromZaLetove(korisnik, lozinka, icao);
      if (provjera) {
        return Response.ok().build();
      }

    } catch (Exception e) {
      e.printStackTrace();
      return Response.serverError().build();
    }
    return Response.serverError().build();
  }

  /**
   * GET metoda koja povezuje aerodrom.jsp i postavlja potrebne podatke unutar Model klase (putanja
   * .../{icao}) prema RestAerodromi
   * 
   * @param icao
   */
  @GET
  @Path("{icao}")
  @View("aerodrom.jsp")
  public void getAerodrom(@PathParam("icao") String icao) {
    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var aerodrom = rca.getAerodrom(icao);
      model.put("aerodrom", aerodrom);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * GET metoda koja povezuje aerodromiLetovi.jsp i metodu WsAerodroma te stalvja potrebno podatke
   * unutar modela.
   * 
   * 
   */
  @GET
  @Path("aerodromiLetovi")
  @View("aerodromiLetovi.jsp")
  public void getAerodromiLetovi(@Context HttpServletRequest request) {
    HttpSession sesija = request.getSession();
    String korisnik = (String) sesija.getAttribute("korIme");
    String lozinka = (String) sesija.getAttribute("lozinka");
    try {

      var port = service.getWsAerodromiPort();
      var aerodrom = port.dajAerodromeZaLetove(korisnik, lozinka);
      model.put("aerodromiLetovi", aerodrom);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @POST
  @Path("aerodromiLetovi/pauziraj/{icao}")
  @View("aerodromiLetoviPauziraj.jsp")
  public Response aerodromiLetoviPauziraj(@PathParam("icao") String icao,
      @Context HttpServletRequest request) {
    HttpSession sesija = request.getSession();
    String korisnik = (String) sesija.getAttribute("korIme");
    String lozinka = (String) sesija.getAttribute("lozinka");
    try {

      var port = service.getWsAerodromiPort();
      port.pauzirajAerodromZaletove(korisnik, lozinka, icao);
      return Response.ok().build();
    } catch (Exception e) {
      e.printStackTrace();
      return Response.serverError().build();
    }
  }

  /**
   * POST metoda koja aktivira status aerodroma tako da se on može koristiti pri preuzimanju letova
   * te koristi metodu WsAerodroma
   * 
   * @param icao
   * @param request
   * @return
   */
  @POST
  @Path("aerodromiLetovi/aktiviraj/{icao}")
  @View("aerodromiLetoviAktiviraj.jsp")
  public Response aerodromiLetoviAktivirajj(@PathParam("icao") String icao,
      @Context HttpServletRequest request) {
    HttpSession sesija = request.getSession();
    String korisnik = (String) sesija.getAttribute("korIme");
    String lozinka = (String) sesija.getAttribute("lozinka");
    try {

      var port = service.getWsAerodromiPort();
      port.aktivirajAerodromZaletove(korisnik, lozinka, icao);
      return Response.ok().build();
    } catch (Exception e) {
      e.printStackTrace();
      return Response.serverError().build();
    }
  }

  /**
   * GET metoda koja povezuje aerodromiUdaljenost1.jsp i postavlja potrebne podatke unutar Model
   * klase .
   * 
   * @param icaoOd
   * @param icaoDo
   */
  @GET
  @Path("udaljenost1")
  @View("aerodromiUdaljenost1.jsp")
  public void getAerodromiUdaljenost(@QueryParam("icaoOd") String icaoOd,
      @QueryParam("icaoDo") String icaoDo) {

    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var udaljenosti = rca.getUdaljenosti(icaoOd, icaoDo);
      model.put("udaljenosti", udaljenosti);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * GET metoda koja povezuje aerodromiUdaljenost2.jsp i postavlja potrebne podatke unutar Model
   * klase .
   * 
   * @param icaoOd
   * @param icaoDo
   */
  @GET
  @Path("udaljenost2")
  @View("aerodromiUdaljenost2.jsp")
  public void getUdaljenostOdDo(@QueryParam("icaoOd") String icaoOd,
      @QueryParam("icaoDo") String icaoDo) {

    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var aerodromi = rca.getUdaljenostiOdDo(icaoOd, icaoDo);

      model.put("aerodromi", aerodromi);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * GET metoda koja povezuje aerodromiUdaljenost3.jsp i postavlja potrebne podatke unutar Model
   * klase .
   * 
   * @param icaoOd
   * @param icaoDo
   */
  @GET
  @Path("udaljenost3")
  @View("aerodromiUdaljenost3.jsp")
  public void getUdaljenostManjaOdDo(@QueryParam("icaoOd") String icaoOd,
      @QueryParam("icaoDo") String icaoDo) {

    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var aerodromi = rca.getUdaljenostiOdDoManja(icaoOd, icaoDo);

      model.put("aerodromi", aerodromi);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * GET metoda koja povezuje aerodromiUdaljenost4.jsp i postavlja potrebne podatke unutar Model
   * klase .
   * 
   * @param icaoOd
   * @param drzava
   * @param km
   */
  @GET
  @Path("udaljenost4")
  @View("aerodromiUdaljenost4.jsp")
  public void getUdaljenostUDrzaviIspodKm(@QueryParam("icaoOd") String icaoOd,
      @QueryParam("drzava") String drzava, @QueryParam("km") String km) {

    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var aerodromi = rca.getUdaljenostiUDrzaviIspodKm(icaoOd, drzava, km);

      model.put("aerodromi", aerodromi);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
