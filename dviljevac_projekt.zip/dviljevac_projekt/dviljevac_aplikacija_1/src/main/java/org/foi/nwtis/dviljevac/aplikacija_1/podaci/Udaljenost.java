package org.foi.nwtis.dviljevac.aplikacija_1.podaci;

import java.io.Serializable;

/**
 * 
 * @author David Viljevac
 *
 */
public record Udaljenost(float gpsS1, float gpsD1, float gpsS2, float gpsD2, double udaljenost)
    implements Serializable {

}
