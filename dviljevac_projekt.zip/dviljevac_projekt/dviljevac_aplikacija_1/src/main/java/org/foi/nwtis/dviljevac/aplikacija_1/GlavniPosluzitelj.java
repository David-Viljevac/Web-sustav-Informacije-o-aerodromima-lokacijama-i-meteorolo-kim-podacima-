package org.foi.nwtis.dviljevac.aplikacija_1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.Konfiguracija;


/**
 * Klasa glavni posluzitelj koja priprema posluzitelja za primanje naredbi od klijenata.
 * 
 * @author David Viljevac
 *
 */

public class GlavniPosluzitelj {
  protected Konfiguracija konfig;
  private static int ispis = 0;
  private int mreznaVrata = 8000;
  private int brojCekaca = 10;
  protected static boolean kraj = true;
  private int brojDretvi;
  protected static ServerSocket posluzitelj;
  public static boolean pauza = true;
  private static int brojZahtjeva = 0;

  /**
   * Konstruktor GlavniPosluzitelj koji ucitava postavke iz objekta klase Konfiguracija
   * 
   * @param konf
   * @see Konfiguracija
   */
  public GlavniPosluzitelj(Konfiguracija konf) {
    super();
    this.konfig = konf;
    this.ispis = Integer.parseInt(konfig.dajPostavku("ispis"));
    this.mreznaVrata = Integer.parseInt(konfig.dajPostavku("mreznaVrata"));
    this.brojCekaca = Integer.parseInt(konfig.dajPostavku("brojCekaca"));
  }

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

  /**
   * Pokreće poslužitelja i učitava sve podatke.
   * 
   */
  public void pokreniPosluzitelj() {
    try {
      pripremiPosluzitelja();
    } catch (IOException e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
    }

  }

  /**
   * Kreira novog poslužitelja na temelju učitanih postavki mreznaVrata i brojCekaca. Neprekidno
   * čeka na zahtjeve klijenta.
   * 
   * @throws IOException
   */
  public void pripremiPosluzitelja() throws IOException {
    posluzitelj = new ServerSocket(this.mreznaVrata, this.brojCekaca);
    while (kraj) {
      Socket veza = posluzitelj.accept();
      MrezniRadnik mr = new MrezniRadnik(veza, konfig);
      mr.setName("dviljevac_" + brojDretvi);
      brojDretvi++;
      mr.start();
    }
  }

  public static synchronized void povecajBrojZahtjeva() {
    brojZahtjeva++;
  }

  public static synchronized int dohvatiBrojZahtjeva() {
    return brojZahtjeva;
  }

  public static synchronized void postaviBrojZahtjevaNaNula() {
    brojZahtjeva = 0;
  }

  public static synchronized void postaviIspisNa0() {
    ispis = 0;
  }

  public static synchronized void postaviIspisNa1() {
    ispis = 1;
  }

  public static synchronized int dohvatiIspis() {
    return ispis;
  }
}
