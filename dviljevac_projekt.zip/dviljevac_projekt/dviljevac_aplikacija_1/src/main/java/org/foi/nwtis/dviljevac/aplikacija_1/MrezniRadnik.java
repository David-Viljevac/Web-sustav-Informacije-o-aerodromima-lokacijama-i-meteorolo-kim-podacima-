package org.foi.nwtis.dviljevac.aplikacija_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.dviljevac.aplikacija_1.podaci.Udaljenost;

/**
 * Klasa mrežnog radnika koja služi kao poveznica klijenta i poslužitelja.
 * 
 * @author David Viljevac
 *
 */

public class MrezniRadnik extends Thread {
  protected Socket mreznaUticnica;
  protected Konfiguracija konfig;
  private int ispis = 0;
  private String komandaRijeci[] = new String[10];
  private static ArrayList<Thread> dretve = new ArrayList<Thread>();

  public static String glavniKlijentZahtjevRegex =
      "((?<status>(STATUS))|(?<info>(INFO (DA|NE)))|(?<udaljenost>(UDALJENOST)) (?<gpsSirina1>((-?[0-9]+.[0-9]+))) (?<gpsDuzina1>((-?[0-9]+.[0-9]+))) (?<gpsSirina2>((-?[0-9]+.[0-9]+))) (?<gpsDuzina2>((-?[0-9]+.[0-9]+)))|(?<kraj>(KRAJ))|(?<init>(INIT))|(?<pauza>(PAUZA)))?";

  /**
   * Konstruktor mrežnog radnika koji služi za učitavanje potrebnih postavki iz konfig.
   * 
   * @param mreznaUticnica
   * @param konfig
   */
  public MrezniRadnik(Socket mreznaUticnica, Konfiguracija konfig) {
    super();
    this.mreznaUticnica = mreznaUticnica;
    this.konfig = konfig;
    this.ispis = Integer.parseInt(this.konfig.dajPostavku("ispis"));
  }

  @Override
  public synchronized void start() {
    // TODO Auto-generated method stub
    super.start();
  }

  /**
   * Prepisana run() metoda koja sada spaja mrežnog radnika odnosno čita i piše odgovore od
   * poslužitelja.
   */
  @Override
  public void run() {
    try {
      var citac = new BufferedReader(
          new InputStreamReader(this.mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
      var pisac = new BufferedWriter(
          new OutputStreamWriter(this.mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));
      var poruka = new StringBuilder();
      Thread dretva = Thread.currentThread();
      dretve.add(dretva);
      while (true) {
        var red = citac.readLine();
        if (red == null) {

          break;

        }
        if (GlavniPosluzitelj.dohvatiIspis() == 1) {
          Logger.getGlobal().log(Level.INFO, red);
        }
        poruka.append(red);
      }
      this.mreznaUticnica.shutdownInput();
      String odgovor = this.obradiZahtjev(poruka.toString());
      pisac.write(odgovor);
      pisac.flush();
      this.mreznaUticnica.shutdownOutput();
      this.mreznaUticnica.close();

    } catch (IOException e) {
      Logger.getGlobal().log(Level.SEVERE, "ERROR 05: " + e.getMessage());
    }
  }

  /**
   * Obrada komande te vraćanje odgovor od strane posluzitelja na klijenta
   * 
   * @param komanda
   * @return
   */
  private String obradiZahtjev(String komanda) {

    String odgovor = "";
    String[] komandaRijeciObradeno = obradiKomandu(komanda);
    odgovor = obradiZahtjevKlijenta(komandaRijeciObradeno, komanda);

    return odgovor;
  }

  /**
   * Obrada zahtjeva klijenta prema tome što komanda sadrži
   * 
   * @param dijeloviProvjereneKomande
   * @param komanda
   * @return
   */
  private String obradiZahtjevKlijenta(String[] dijeloviProvjereneKomande, String komanda) {
    String odgovor = "";
    if (dijeloviProvjereneKomande == null) {
      return "ERROR 05: Pogrešan format komande";
    }
    if (dijeloviProvjereneKomande[0] != "") {
      odgovor += obradiStatus();
    }
    if (dijeloviProvjereneKomande[1] != "") {
      odgovor += obradiInfo(dijeloviProvjereneKomande[1]);
    }
    if (dijeloviProvjereneKomande[2] != "") {
      Udaljenost udaljenost = new Udaljenost(Float.parseFloat(dijeloviProvjereneKomande[3]),
          Float.parseFloat(dijeloviProvjereneKomande[4]),
          Float.parseFloat(dijeloviProvjereneKomande[5]),
          Float.parseFloat(dijeloviProvjereneKomande[6]), 0);

      odgovor += obradiUdaljenost(udaljenost);
    }
    if (dijeloviProvjereneKomande[7] != "") {
      odgovor += obradiKraj();
    }
    if (dijeloviProvjereneKomande[8] != "") {
      odgovor += obradiInit();
    }
    if (dijeloviProvjereneKomande[9] != "") {
      odgovor += obradiPauza();
    }

    return odgovor;
  }

  /**
   * Obrađivanje pauze i stavljanje poslužitelja u pauzu
   * 
   * @return
   */
  private String obradiPauza() {
    String odgovor = "OK ";
    if (GlavniPosluzitelj.pauza == true) {
      return "ERROR 01: Poslužitelj je već u pauzi!";
    }
    GlavniPosluzitelj.pauza = true;
    odgovor += "" + GlavniPosluzitelj.dohvatiBrojZahtjeva();
    return odgovor;
  }

  /**
   * Metoda inicijalizacije posluzitelja
   * 
   * @return
   */
  private String obradiInit() {
    String odgovor = "OK ";
    if (GlavniPosluzitelj.pauza == false) {
      return "ERROR 02: Poslužitelj je već aktivan!";
    }
    GlavniPosluzitelj.postaviBrojZahtjevaNaNula();
    GlavniPosluzitelj.pauza = false;
    return odgovor;
  }

  /**
   * Metoda gašenja poslužitelja
   * 
   * @return
   */
  private String obradiKraj() {
    String odgovor = "OK ";
    try {
      GlavniPosluzitelj.posluzitelj.close();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    for (Thread dretva : dretve) {
      dretva.interrupt();
    }
    return odgovor;
  }

  /**
   * Metoda koja vraća udaljenost dviju točki na zemljinoj površini
   * 
   * @param trenutnaUdaljenost
   * @return
   */
  private String obradiUdaljenost(Udaljenost trenutnaUdaljenost) {
    if (GlavniPosluzitelj.pauza == true) {
      return "ERROR 01: Poslužitelj je na pauzi";
    }
    String odgovor = "";
    double udaljenost = 0;
    if ((trenutnaUdaljenost.gpsS1() == trenutnaUdaljenost.gpsS2())
        && (trenutnaUdaljenost.gpsD1() == trenutnaUdaljenost.gpsD2())) {
      return "OK 0";
    } else {
      double razlikaDuzina = trenutnaUdaljenost.gpsD1() - trenutnaUdaljenost.gpsD2();
      double udaljenostLokacija = Math.sin(Math.toRadians(trenutnaUdaljenost.gpsS1()))
          * Math.sin(Math.toRadians(trenutnaUdaljenost.gpsS2()))
          + Math.cos(Math.toRadians(trenutnaUdaljenost.gpsS1()))
              * Math.cos(Math.toRadians(trenutnaUdaljenost.gpsS2()))
              * Math.cos(Math.toRadians(razlikaDuzina));
      udaljenostLokacija = Math.acos(udaljenostLokacija);
      udaljenostLokacija = Math.toDegrees(udaljenostLokacija);
      udaljenostLokacija = udaljenostLokacija * 60 * 1.1515;
      udaljenostLokacija = udaljenostLokacija * 1.609344;
      DecimalFormat df = new DecimalFormat("#####.##");
      udaljenost = Double.valueOf(df.format(udaljenostLokacija));
    }
    odgovor = "OK " + udaljenost;
    GlavniPosluzitelj.povecajBrojZahtjeva();
    return odgovor;
  }

  /**
   * Metoda zatvaranja ili otvaranja ispisa poslužitelja
   * 
   * @param komanda
   * @return
   */
  private String obradiInfo(String komanda) {
    String odgovor = "";
    if (komanda.contains("DA")) {
      if (GlavniPosluzitelj.dohvatiIspis() == 1) {
        return "ERROR 03: Poslužitelj već ispisuje podatke na standardni izlaz";
      }
      odgovor = "OK";
      this.ispis = 1;
      GlavniPosluzitelj.postaviIspisNa1();
    } else {
      if (GlavniPosluzitelj.dohvatiIspis() == 0) {
        return "ERROR 04: Poslužitelj već ne ispisuje podatke na standardni izlaz";
      }
      odgovor = "OK";
      this.ispis = 0;
      GlavniPosluzitelj.postaviIspisNa0();
    }
    return odgovor;
  }

  /**
   * Metoda obrade statusa odnosno prikaza stanja u kojem je poslužitelj
   * 
   * @return
   */
  private String obradiStatus() {
    String odgovor = "";
    if (GlavniPosluzitelj.pauza == true) {
      odgovor = "OK 0";

    } else {
      odgovor = "OK 1";
    }
    return odgovor;
  }


  /**
   * Popunjavanje liste dijelova komande prema komandu i regexu.
   * 
   * @param komanda
   * @return
   */
  public String[] obradiKomandu(String komanda) {
    Pattern pattern = Pattern.compile(glavniKlijentZahtjevRegex);
    if (pattern.matches(glavniKlijentZahtjevRegex, komanda)) {
      pattern = Pattern.compile(glavniKlijentZahtjevRegex);
      Matcher m = pattern.matcher(komanda);
      boolean status = m.matches();
      popunjavanjePremaGlavniKlijentZahtjev(m, status);
      return komandaRijeci;
    } else {
      return komandaRijeci = null;
    }
  }

  /**
   * Pridruživanje vrijednosti određenim mjestima u listi prema regexu zahtjeva glavnog klijenta.
   * 
   * @param m
   * @param status
   */
  private void popunjavanjePremaGlavniKlijentZahtjev(Matcher m, boolean status) {
    if (status) {
      komandaRijeci[0] = (m.group("status") == null) ? "" : m.group("status");
      komandaRijeci[1] = (m.group("info") == null) ? "" : m.group("info");
      komandaRijeci[2] = (m.group("udaljenost") == null) ? "" : m.group("udaljenost");
      komandaRijeci[3] = (m.group("gpsSirina1") == null) ? "" : m.group("gpsSirina1");
      komandaRijeci[4] = (m.group("gpsDuzina1") == null) ? "" : m.group("gpsDuzina1");
      komandaRijeci[5] = (m.group("gpsSirina2") == null) ? "" : m.group("gpsSirina2");
      komandaRijeci[6] = (m.group("gpsDuzina2") == null) ? "" : m.group("gpsDuzina2");
      komandaRijeci[7] = (m.group("kraj") == null) ? "" : m.group("kraj");
      komandaRijeci[8] = (m.group("init") == null) ? "" : m.group("init");
      komandaRijeci[9] = (m.group("pauza") == null) ? "" : m.group("pauza");
    }
  }

  @Override
  public void interrupt() {
    // TODO Auto-generated method stub
    super.interrupt();
  }

}
