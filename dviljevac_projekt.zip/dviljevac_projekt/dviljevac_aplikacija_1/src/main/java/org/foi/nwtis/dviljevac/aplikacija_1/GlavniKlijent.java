package org.foi.nwtis.dviljevac.aplikacija_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Klasa GlavniKlijent predstavlja klijenta koji šalje zahtjev na poslužitelja
 * 
 * @author David Viljevac
 *
 */
public class GlavniKlijent {
  private String uzorak =
      "((?<status>(STATUS))|(?<info>(INFO (DA|NE)))|(?<udaljenost>(UDALJENOST)) (?<gpsSirina1>((-?[0-9]+.[0-9]+))) (?<gpsDuzina1>((-?[0-9]+.[0-9]+))) (?<gpsSirina2>((-?[0-9]+.[0-9]+))) (?<gpsDuzina2>((-?[0-9]+.[0-9]+)))|(?<kraj>(KRAJ))|(?<init>(INIT))|(?<pauza>(PAUZA)))";

  protected Pattern regex = Pattern.compile(uzorak);


  /**
   * Main metoda koja instancira glavnog klijentate se šalje zahtjev.
   * 
   * @param args
   */
  public static void main(String[] args) {
    GlavniKlijent gk = new GlavniKlijent();
    String input = String.join(" ", args);
    if (!gk.isKorektanFormat(input)) {
      Logger.getGlobal().log(Level.SEVERE, "Nisu upisani ispravni argumenti");
      return;
    }

    gk.posaljiZahtjev(input);
  }

  /**
   * Provjera odgovara li upisana komanda regexu odnosno je li dobrog formata.
   * 
   * @param input
   * @return
   */
  private boolean isKorektanFormat(String input) {

    Matcher matcher = this.regex.matcher(input);
    return matcher.matches();
  }

  /**
   * Šalje komandu i spaja se na mreznu uticnicu
   * 
   * @param komanda
   */
  private void posaljiZahtjev(String komanda) {
    try {
      var mreznaUticnica = new Socket("localhost", 8000);
      var citac = new BufferedReader(
          new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
      var pisac = new BufferedWriter(
          new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));

      var poruka = new StringBuilder();
      pisac.write(komanda);
      pisac.flush();
      mreznaUticnica.shutdownOutput();
      while (true) {
        var red = citac.readLine();
        if (red == null) {
          break;
        }
        Logger.getGlobal().log(Level.INFO, red);

        poruka.append(red);
      }
      mreznaUticnica.shutdownInput();
      mreznaUticnica.close();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

}

