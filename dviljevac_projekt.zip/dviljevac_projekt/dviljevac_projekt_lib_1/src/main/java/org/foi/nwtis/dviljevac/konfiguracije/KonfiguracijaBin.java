package org.foi.nwtis.dviljevac.konfiguracije;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;

/**
 * Klasa za čitanje bin datoteke sa postavkama.
 * 
 * @author David Viljevac
 *
 */
public class KonfiguracijaBin extends KonfiguracijaApstraktna {
  /**
   * Konstanta TIP
   */
  public static final String TIP = "bin";

  /**
   * Kontruktor
   * 
   * @param nazivDatoteke - naziv datoteke
   */
  public KonfiguracijaBin(String nazivDatoteke) {
    super(nazivDatoteke);
    // TODO Auto-generated constructor stub
  }

  /**
   * Spremanje konfiguracije u datoteku .bin formata
   */
  @Override
  public void spremiKonfiguraciju(String datoteka) throws NeispravnaKonfiguracija {
    var putanja = Path.of(datoteka);
    var tip = Konfiguracija.dajTipKonfiguracije(datoteka);
    if (tip == null || tip.compareTo(TIP) != 0) {
      throw new NeispravnaKonfiguracija(
          "Datoteka ' " + datoteka + "' nije ispravnog tipa: '" + TIP + "'");
    } else if (Files.exists(putanja)
        && (Files.isDirectory(putanja) || !Files.isWritable(putanja))) {
      throw new NeispravnaKonfiguracija(
          "Datoteka ' " + datoteka + "' je direktorij ili nije moguće pisati u nju.");
    }

    try {
      FileOutputStream fos = new FileOutputStream(datoteka);
      ObjectOutputStream oos = new ObjectOutputStream(fos);
      oos.writeObject(this.postavke);
      oos.close();
    } catch (IOException e) {
      throw new NeispravnaKonfiguracija(
          "Datoteka ' " + datoteka + "' nije moguće pisati." + e.getMessage());
    }

  }

  /**
   * Učitavanje konfiguracije iz .bin formata datoteke.
   */
  @Override
  public void ucitajKonfiguraciju() throws NeispravnaKonfiguracija {
    var datoteka = this.nazivDatoteke;
    var putanja = Path.of(datoteka);
    var tip = Konfiguracija.dajTipKonfiguracije(datoteka);

    if (tip == null || tip.compareTo(TIP) != 0) {
      throw new NeispravnaKonfiguracija("Datoteka '" + datoteka + "' nije tip " + TIP);
    } else if (Files.exists(putanja)
        && (Files.isDirectory(putanja) || !Files.isReadable(putanja))) {
      throw new NeispravnaKonfiguracija(
          "Datoteka '" + datoteka + "' je direktorij ili nije moguće čitat.");
    }

    try {
      FileInputStream fis = new FileInputStream(datoteka);
      ObjectInputStream ois = new ObjectInputStream(fis);
      this.postavke = (Properties) ois.readObject();
      ois.close();
    } catch (IOException e) {
      throw new NeispravnaKonfiguracija(
          "Datoteka '" + datoteka + "' nije moguće čitati. " + e.getMessage());
    } catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

  }

}
