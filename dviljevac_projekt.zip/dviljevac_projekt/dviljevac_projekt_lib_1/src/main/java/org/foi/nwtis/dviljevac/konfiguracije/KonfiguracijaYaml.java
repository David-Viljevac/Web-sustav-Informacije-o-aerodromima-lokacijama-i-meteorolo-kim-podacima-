package org.foi.nwtis.dviljevac.konfiguracije;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;
import org.yaml.snakeyaml.Yaml;



/**
 * Klasa za čitanje yaml datoteke sa postavkama.
 * 
 * @author David Viljevac
 *
 */
public class KonfiguracijaYaml extends KonfiguracijaApstraktna {
  /**
   * Konstanta TIP
   */
  public static final String TIP = "yaml";

  /**
   * Kontruktor
   * 
   * @param nazivDatoteke - naziv datoteke
   */
  public KonfiguracijaYaml(String nazivDatoteke) {
    super(nazivDatoteke);
    // TODO Auto-generated constructor stub
  }

  /**
   * Sprema postavke u yaml datoteku. Potrebno završiti.
   */
  @Override
  public void spremiKonfiguraciju(String datoteka) throws NeispravnaKonfiguracija {
    var putanja = Path.of(datoteka);
    var tip = Konfiguracija.dajTipKonfiguracije(datoteka);
    if (tip == null || tip.compareTo(TIP) != 0) {
      throw new NeispravnaKonfiguracija(
          "Datoteka ' " + datoteka + "' nije ispravnog tipa: '" + TIP + "'");
    } else if (Files.exists(putanja)
        && (Files.isDirectory(putanja) || !Files.isWritable(putanja))) {
      throw new NeispravnaKonfiguracija(
          "Datoteka ' " + datoteka + "' je direktorij ili nije moguće pisati u nju.");
    }
    // spremanje sloziti
    /*
     * Properties props; try { Yaml yaml = new Yaml(); props =
     * yaml.loadAs(YamlPropertiesReaderWriter.class.getResourceAsStream(datoteka),
     * Properties.class); } catch (Exception e) { e.printStackTrace(); }
     * 
     * try { Yaml yaml = new Yaml(getDumperOptions()); FileWriter writer = new
     * FileWriter("config.yaml"); yaml.dump(props, writer); } catch (IOException e) {
     * e.printStackTrace(); }
     */

  }

  /**
   * Učitavanje konfiguracije iz .yaml formata datoteke
   */
  @Override
  public void ucitajKonfiguraciju() throws NeispravnaKonfiguracija {
    var datoteka = this.nazivDatoteke;
    var putanja = Path.of(datoteka);
    var tip = Konfiguracija.dajTipKonfiguracije(datoteka);

    if (tip == null || tip.compareTo(TIP) != 0) {
      throw new NeispravnaKonfiguracija(
          "Datoteka '" + datoteka + "' nije ispravnog tipa: '" + TIP + "'");
    } else if (Files.exists(putanja)
        && (Files.isDirectory(putanja) || !Files.isReadable(putanja))) {
      throw new NeispravnaKonfiguracija(
          "Datoteka '" + datoteka + "' je direktorij ili nije moguće ćitati iz nje.");
    }

    try {
      Yaml yaml = new Yaml();
      FileInputStream tekst = new FileInputStream(datoteka);
      Map<String, Object> map = yaml.load(tekst);
      Properties postavkeYaml = new Properties();
      for (Map.Entry<String, Object> red : map.entrySet()) {
        postavkeYaml.setProperty(red.getKey(), red.getValue().toString());
      }
      this.postavke = postavkeYaml;
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }

  }

  /*
   * private static DumperOptions getDumperOptions() { DumperOptions options = new DumperOptions();
   * options.setPrettyFlow(true); options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
   * options.setAllowUnicode(true); return options; }
   */
}
